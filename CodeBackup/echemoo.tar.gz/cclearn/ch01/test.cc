#include <iostream>
#include "Sales_item.h"
int main(){
	Sales_item val;
	int cnt =0;
	while (std::cin>> val)
		++cnt;
	std::cout<< val.isbn() << "\t count:" << cnt << std::endl;
	return 0;
}
