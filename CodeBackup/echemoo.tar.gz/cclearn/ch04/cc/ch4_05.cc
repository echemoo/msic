#include <iostream>
using std::cout;
using std::endl;
int main(){
	cout << -30 * 3 + 21 / 5 << endl;
	cout << -30 + 3 * 21 / 5 << endl;
	cout << 30 / 3 * 21 % 5 << endl;
	cout << -30 / 3 * 21 % 4 << endl;
	cout << 86 << '\t' << -18 << '\t' << 0 << '\t' << -2 << endl;
	return 0;
}
