#include <iostream>
using std::cout;
using std::endl;
int main(){
	cout << 5 + 10 * 20 /2 << endl;
}
