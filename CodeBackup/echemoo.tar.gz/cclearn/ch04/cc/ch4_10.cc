#include <iostream>
#include <cstdlib>
#include <ctime>
using std::cout;
using std::endl;
int main(){
	srand(unsigned(time(NULL)));
	unsigned mm = rand() % 100;
	while (mm && (mm != 42)){
		cout << mm << '\t';
		mm = rand() % 100;
	}	
	cout << endl;
	return 0;
}
