#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <bitset>
using std::cout;
using std::endl;
using std::vector;
using std::bitset;
int main(){
	srand(unsigned(time(NULL)));
	vector<bool> vb;
	for (unsigned i = 0; i < sizeof(long) * 8; ++i)
		vb.push_back(rand() % 2);
	for (unsigned i =0; i < sizeof(long) * 8; ++i)
		cout << vb[sizeof(long) * 8 - 1 - i];
	cout << endl;
	unsigned long quiz1 = 0;
	for (unsigned i = 0; i < sizeof(long) * 8; ++i)
		quiz1 |= vb[i] << i;
	cout << bitset<sizeof(long) * 8>(quiz1) << endl; 
	quiz1 |= 1UL << 27;
	cout << bitset<sizeof(long) * 8>(quiz1) << endl; 
	quiz1 &= ~(1UL << 27);
	cout << bitset<sizeof(long) * 8>(quiz1) << endl; 
	bool status = quiz1 & (1UL << 27);
	cout << status << endl;
	return 0;
}
