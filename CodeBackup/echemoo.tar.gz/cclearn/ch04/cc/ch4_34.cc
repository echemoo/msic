#include <iostream>
using std::cout;
using std::endl;
int main(){
	float fval{0.0};
	double dval{0.0};
	int ival{0};
	char cval{0};
	if (fval);
	cout << "fval转换为bool，fval为0时false，否则为true" << endl;
	dval = fval + ival;
	cout << "ival提升为float然后加上fval 结果提升为double" << endl;
	dval + ival * cval;
	cout << "cval提升为int，然后乘以ival，结果提升为double后与dval相加" 
		<< endl;
	return 0;
}
