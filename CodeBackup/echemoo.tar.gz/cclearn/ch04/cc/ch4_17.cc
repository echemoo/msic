#include <iostream>
using std::cout;
using std::endl;
int main(){
	cout << "前置返回左值，后置返回右值" << endl;
	cout << "前置返回增加后的值，后置返回增加前的值" << endl;
	cout << "前置少一次计算，后置多一次计算" << endl;
	cout << "前置为左结合性，后置为右结合" << endl;
	cout << "前置优先级高于右值优先级" << endl;
	return 0;
}
