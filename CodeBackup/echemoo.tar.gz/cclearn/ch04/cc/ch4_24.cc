#include <iostream>
#include <cstdlib>
#include <ctime>
using std::cout;
using std::endl;
int main(){
	srand(unsigned(time(NULL)));
	int grade = rand() % 100;
	cout << grade << endl;
	cout << ((grade < 60 ? "fail" : grade) >= 90 ? "High pase" : "pass") << endl;
	return 0;
}
