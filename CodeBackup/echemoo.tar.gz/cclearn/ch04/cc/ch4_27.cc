#include <iostream>
#include <bitset>
using std::cout;
using std::endl;
using std::bitset;
int main(){
	unsigned long ul1 = 3, ul2 = 2;
	cout << (ul1 & ul2) << endl;
	cout << (ul1 | ul2) << endl;
	cout << (ul1 && ul2) << endl;
	cout << (ul1 || ul2) << endl;
	cout << bitset<sizeof(int) * 8>(ul1 & ul2) << endl;
	cout << bitset<sizeof(int) * 8>(ul1 | ul2) << endl;
	cout << bitset<sizeof(int) * 8>(ul1 && ul2) << endl;
	cout << bitset<sizeof(int) * 8>(ul1 || ul2) << endl;
	return 0;
}
