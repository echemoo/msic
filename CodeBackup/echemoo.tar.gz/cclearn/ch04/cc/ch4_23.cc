#include <iostream>
#include <string>
using std::string;
using std::cout;
using std::endl;
int main(){
	string s = "word";
	string pl = s + (s[(s.size() - 1)] == 's' ? "" : "s");
	cout << pl << endl;
	return 0;
}
