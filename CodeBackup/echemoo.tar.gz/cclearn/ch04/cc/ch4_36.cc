#include <iostream>
using std::cout;
using std::endl;
int main (){
	int i{0};
	double d{0.0};
	i *= static_cast<int>(d);
	return 0;
}
