#include <iostream>
using namespace std;
int getPtr();
int main(){
	int i, p;
	if (p = getPtr() != 0)
		;
	if (i = 1024)
		;
	return 0;
}
int getPtr(){
	return 0;
}
