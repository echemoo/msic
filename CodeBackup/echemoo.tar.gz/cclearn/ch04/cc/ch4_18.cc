#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
using std::cout;
using std::endl;
using std::vector;
int main (){
	srand(int(time(NULL)));
	int count = rand() % 50;
	count = count > 0 ? count : -count;
	cout << "count:\t" << count << endl;
	vector<int> vival;
	for (int i = 0; i < count; ++i)
		vival.push_back(rand() % 100);
	auto pbeg = vival.begin();
	while (pbeg != vival.end() && *pbeg >= 0)
		//cout << *pbeg++ << '\t';
		cout << *++pbeg << '\t';//Error:最后一个解引用报错。
	cout << endl;
	return 0;
}

