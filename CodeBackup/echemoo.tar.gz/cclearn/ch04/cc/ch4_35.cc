#include <iostream>
using std::cout;
using std::endl;
int main(){
	char cval{0};
	int ival{0};
	unsigned int ui{0};
	float fval{0.0};
	double dval{0.0};
	cval = 'a' + 3;
	cout << "'a'提升为int与3相加，然后结果转换为char赋值给cval。" << endl;
	fval = ui - ival * 1.0;
	cout << "ival提升为double与1.0相乘，ui提升为double与结果相减，而后转换为float赋值给fval" << endl;
	dval = ui * fval;
	cout << "ui提升为float后与fval相乘，而后提升为double复制给dval" << endl;
	cval = ival + fval + dval;
	cout << "ival提升为float与fval相加，结果提升为double与dval相加，然后转换为char类型赋值给cval" << endl;
	return 0;
}
