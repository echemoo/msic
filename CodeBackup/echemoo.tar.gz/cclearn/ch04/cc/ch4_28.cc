#include <iostream>
#include <vector>
#include <string>
using std::cout;
using std::endl;
using std::vector;
using std::string;
int main(){
	cout << "bool:\t" << sizeof(bool) << endl;
	cout << "short:\t" << sizeof(short) << endl;
	cout << "int:\t" << sizeof(int) << endl;
	cout << "char:\t" << sizeof(char) << endl;
	cout << "long:\t" << sizeof(long) << endl;
	cout << "long long:\t" << sizeof(long long) << endl;
	cout << "float:\t" << sizeof(float) << endl;
	cout << "double:\t" << sizeof(double) << endl;
	cout << "long double:\t" << sizeof(long double) << endl;
	cout << "int *:\t" << sizeof(int *) << endl;
	cout << "string:\t" << sizeof(string) << endl;
	cout << "vector<int>:\t" << sizeof(vector<int>) << endl;
	return 0;
}
