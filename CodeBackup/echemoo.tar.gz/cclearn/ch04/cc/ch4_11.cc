#include <iostream>
#include <cstdlib>
#include <ctime>
using std::endl;
using std::cout;
int main(){
	int a{0},b{0},c{0},d{0};
	srand(unsigned(time(NULL)));
	while (!(a > b && b > c && c > d)){
		a = rand() % 100;
		b = rand() % 100;
	   	c = rand() % 100;
		d = rand() % 100;	
	}
	cout << "a:" << a << "\tb:" << b << "\tc:" 
		<< c << "\td:" << d << endl;
}
