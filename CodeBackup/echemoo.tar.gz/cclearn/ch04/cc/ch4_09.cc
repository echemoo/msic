#include <iostream>
using std::cout;
using std::endl;
int main(){
	const char *cp = "Hello World!";
	cout << cp << endl;
	if (cp && *cp)
		cout << *cp << '\t';
	cout << endl;
	cout << "cp指向有效，且不指向空字符。" << endl;
	return 0;
}
