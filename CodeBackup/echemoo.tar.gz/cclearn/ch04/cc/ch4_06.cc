#include <iostream>
#include <cstdlib>
#include <ctime>
using std::cout;
using std::endl;
int main(){
	srand(unsigned(time(NULL)));
	int m_i = rand() % 100;
	cout << "随机数字为：" << m_i << endl;
	cout << m_i << "为" << (m_i % 2 ? "奇数" : "偶数") << endl;
	return 0;
}
