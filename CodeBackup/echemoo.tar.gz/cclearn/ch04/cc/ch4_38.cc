#include <iostream>
using std::cout;
using std::endl;
int main(){
	int i = 100;
	int j = 342;
	double slope = static_cast<double>(j/i);
	cout << slope << endl;
	cout << "j除以i去掉整数部分后转换为double类型，赋值给slope。" << endl;
	return 0;
}
