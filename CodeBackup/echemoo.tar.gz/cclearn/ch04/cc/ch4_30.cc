#include <iostream>
using std::cout;
using std::endl;
long f();
class cp
{
	public:
	int men[100];
};
int main(){
	int x{10}, y{23};
	int a{21}, b{22};
	int i = 10;
	cp *p = new cp();
	cout << sizeof (x + y) << endl;
	cout << sizeof p->men[i] << endl;
	cout << sizeof (a < b) << endl;
	cout << sizeof f() << endl;
	return 0;
}
long f()
{
	return 0;
}
