#include <iostream>
#include <bitset>
using std::cout;
using std::endl;
using std::bitset;
int main(){
	cout << sizeof(int) * 8 << endl;
	cout << sizeof(char) * 8 << endl;
	cout << bitset<sizeof(char)*8>('p') << endl;
	cout << bitset<sizeof(int)*8>(~'p') << endl;
	cout << bitset<sizeof(int)*8>(~'p'<< 6 ) << endl;
	cout << (~'q' << 6) << endl;
	return 0;
}
