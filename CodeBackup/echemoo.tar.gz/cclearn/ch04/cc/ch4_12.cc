#include <iostream>
#include <cstdlib>
#include <ctime>
using std::cout;
using std::endl;
int main(){
	int i{0}, j{0}, k{0};
	cout << "i != 0，j > k 条件成立" << endl;
	while (!(i != 0 && i != j < k)){
		i = rand() % 100;
		j = rand() % 100;
		k = rand() % 100;
	}
	cout << "i:" << i << "\tj:" << j << "\tk:" << k << endl;
	cout << "i!=j<k : " << (i != j < k ? "true" : "false") << endl;
	cout << "i = 0, j < k条件成立" << endl;
	while (!(i == 0 && i != j < k)){
		i = rand() % 100;
		j = rand() % 100;
		k = rand() % 100;
	}
	cout << "i:" << i << "\tj:" << j << "\tk:" << k << endl;
	cout << "i!=j<k : " << (i != j < k ? "true" : "false") << endl;
	return 0;
}
