#include <iostream>
#include <bitset>
using std::bitset;
using std::cout;
using std::endl;
int main(){
	int x[10]{};
	int *p = x;
	cout << sizeof(x)/sizeof(*x) << endl;
	cout << sizeof(p)/sizeof(*p) << endl;
	cout << p << endl;
	long aaa = reinterpret_cast<long>(p);
	cout << bitset<sizeof(int *) * 8>(p) << endl;
	cout << bitset<sizeof(int *) * 8>(aaa) << endl;
	cout << *p << endl;
	return 0;
}
