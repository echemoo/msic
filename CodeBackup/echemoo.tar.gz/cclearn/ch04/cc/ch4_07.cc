#include <iostream>
using std::endl;
using std::cout;
int main(){
	int m_ui{-1};
	unsigned mm = 1;
	cout << "max_num=" << m_ui * mm << endl;
	m_ui = 4294967294 + 100;
	cout << m_ui << endl;
	m_ui = 10000000 * 10000000;
	cout << m_ui << endl;
	m_ui = 4294967294 << 2;	
	cout << m_ui << endl;
	return 0;
}
