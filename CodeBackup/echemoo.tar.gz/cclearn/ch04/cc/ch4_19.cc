#include <iostream>
#include <vector>
using namespace std;
int main(){
	int *ptr{nullptr};
	vector<int> vec;
	int ival{0};
	cout << (ptr != 0 && *ptr++) << endl;
	cout << "判断ptr指向是否有效，若有效，判断所指的值是否为0，并移动指针。" << endl;
	cout << (ival++ && ival) << endl;
	cout << "判断ival是否为0并将ival加1，不为0则判断加1后是否为0" << endl;
	cout << (vec[ival++] <= vec[ival]) << endl;
	cout << "错误，无法界定左右两边的计算顺序。" << endl;
	return 0;
}
