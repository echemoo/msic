#include <iostream>
using std::cout;
using std::endl;
int main(){
	cout << "&&\t" << "||\t" << "== !=" << endl;
	return 0;
}
