#include <iostream>
using std::cout;
using std::endl;
int main(){
	int a{0},b{0},c{0};
	a++;
	cout << a + a -1 << endl;
	cout << (b + (b++)) << endl;
	cout << c + c++ << endl;
	return 0;
}
