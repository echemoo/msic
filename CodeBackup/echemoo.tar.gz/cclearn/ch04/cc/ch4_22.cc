#include <iostream>
#include <cstdlib>
#include <ctime>
using std::cout;
using std::endl;
int main(){
	srand(unsigned(time(NULL)));
	int grade = rand() % 100;
	cout << grade << endl;
	cout << (grade < 60 ? "fail" : grade >= 90 ? "High pase" : 
			grade < 75 ? "Low pass" : "pass") << endl;
	if (grade >= 90)
		cout << "High pass" << endl;
	else if(grade >= 75 && grade < 90)
		cout << "Pass" << endl;
	else if (grade >=60 && grade < 75)
		cout << "Low pass" << endl;
	else if (grade < 60)
		cout << "fail" << endl;
	return 0;
}
