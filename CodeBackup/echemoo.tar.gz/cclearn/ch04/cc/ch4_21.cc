#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
using std::cout;
using std::endl;
using std::vector;
int main(){
	vector<int> vi;
	srand(int(time(NULL)));
	int count = rand() % 50;
	count = count > 0 ? count : -count;
	cout << "count:\t" << count << endl;
	for (int i = 0; i <= count; ++i)
		vi.push_back(rand() % 1000);
	for (auto i : vi)
		cout << i << '\t';
	cout << endl;
	for (auto it = vi.begin(); it != vi.end(); ++it)
		if (*it % 2)
			*it *= 2;
	for (auto i : vi)
		cout << i << '\t';
	cout << endl;
	return 0;
}
