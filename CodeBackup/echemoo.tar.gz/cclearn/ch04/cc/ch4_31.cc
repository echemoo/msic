#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
using std::cout;
using std::endl;
using std::vector;
int main(){
	vector<int> vi;
	srand(int(time(NULL)));
	int count = rand() % 100;
	count = count > 0 ? count : -count;
	for (int i = 0; i < count; i++)
		vi.push_back(rand() % 100);
	vector<int>::size_type cnt = vi.size();
	for(auto item : vi)
		cout << item << '\t';
	cout << endl;
	for(vector<int>::size_type ix = 0; ix != vi.size(); ix++, cnt--)
		vi[ix] = cnt;
	for(auto item : vi)
		cout << item << '\t';
	cout << endl;
	return 0;
}
