#include <iostream>
#include <vector>
#include <string>
using namespace std;
int main(){
	vector<string> vsval(10,"Hello");
	vector<string>::iterator iter = vsval.begin();
	*iter++;  //OK
	(*iter)++; //ERROR
	*iter.empty();//ERROR
	iter->empty();//OK
	++*iter;//ERROR
	iter++->empty();//OK
	return 0;
}
