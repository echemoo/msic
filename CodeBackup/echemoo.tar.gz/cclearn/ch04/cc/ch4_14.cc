#include <iostream>
using namespace std;
int main(){
	int i;
	if (42=i)//报错
		;
	if (i=42)//恒为真
		;
	return 0;
	
}
