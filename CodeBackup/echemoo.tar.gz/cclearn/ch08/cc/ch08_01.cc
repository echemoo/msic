#include <cstdlib>
#include <iostream>
#include <string>
using std::istream;
using std::ostream;
using std::string;
using std::ends;
using std::endl;
using std::cout;
using std::cin;
istream &test(istream &io){
    string str;
    while(!io.eof()){
        io >> str;
        cout << str << ends;
    }
    io.clear();
    return io;
}
