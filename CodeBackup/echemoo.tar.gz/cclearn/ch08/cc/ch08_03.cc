#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "遇到文件结束符；遇到系统故障；读入无效数据。" << endl;
	return EXIT_SUCCESS;
}
