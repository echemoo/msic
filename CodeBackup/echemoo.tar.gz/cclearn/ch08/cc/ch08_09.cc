#include <cstdlib>
#include <iostream>
#include <string>
#include <sstream>
using std::istream;
using std::ostream;
using std::string;
using std::ends;
using std::endl;
using std::cout;
using std::cin;
using std::stringstream;
istream &test(istream &io){
    string str;
    while(!io.eof()){
        io >> str;
        cout << str << ends;
    }
    io.clear();
    return io;
}
ostream &test_show(ostream &oo, stringstream &ss){
    string str;
    while (ss >> str)
        oo << str << ' ';
    oo << endl;
    return oo;
} 
int main(int argc, char **argv){
    stringstream ss;
    string str = "Hello World!\n";
    ss << str;
    test_show(cout, ss);
}
