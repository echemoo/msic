#include <fstream>
#include <cstdlib>
#include <string>
#include <vector>
#include <iostream>
using std::vector;
using std::string;
using std::endl;
using std::cout;
using std::cin;
using std::ifstream;
using std::ofstream;
void read(ifstream &io, vector<string> &vs){
    string str;
    while(io >> str){
        vs.push_back(str);
    }
    io.clear();
    return;
}
int main(int argc, char **argv){
    if (argc < 2){
        cout << "Please point input file." << endl;
        return EXIT_FAILURE;
    }
    ifstream iof(argv[1]);
    if (iof.fail()){
        cout << "Input file is inviold." << endl;
        return EXIT_FAILURE;
    }
    vector<string> vss;
    read(iof, vss);
    iof.close();
    for(auto &item : vss)
        cout << item << endl;
    return EXIT_SUCCESS;
}
