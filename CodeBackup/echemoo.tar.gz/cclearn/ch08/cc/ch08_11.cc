#include <iostream>
#include <sstream>
#include <fstream>
#include <cstdlib>
#include <vector>
#include <string>
using std::cout;
using std::endl;
using std::cerr;
using std::vector;
using std::string;
using std::istringstream;
using std::ifstream;
using std::cin;
struct PersonInfo{
    string name;
    vector<string> phones;
};
int main(int argc, char **argv){
    if (argc < 2){
        cout << "Please point input file." << endl;
        return EXIT_FAILURE;
    }
    ifstream iof(argv[1]);
    if (iof.fail()){
        cout << "Input file is inviold." << endl;
        return EXIT_FAILURE;
    }
    string line, word;
    vector<PersonInfo> people;
    istringstream record;
    while (getline(iof, line)){
        PersonInfo info;
        record.str(line);
        record >> info.name;
        while (record >> word)
            info.phones.push_back(word);
        people.push_back(info);
        record.clear();
    }
    iof.close();
    return EXIT_SUCCESS;
}
