#include <iostream>
#include <cstdlib>
#include <sstream>
#include <fstream>
#include <vector>
#include <string>
using std::string;
using std::vector;
using std::ifstream;
using std::istringstream;
using std::cout;
using std::endl;
int main(int argc, char **argv){
    if (argc < 2){
        cout << "Please point input file." << endl;
        return EXIT_FAILURE;
    }
    ifstream iof(argv[1]);
    if (iof.fail()){
        cout << "Input file is inviold." << endl;
        return EXIT_FAILURE;
    }
    vector<string> vs;
    string str;
    while (getline(iof, str))
        vs.push_back(str);
    istringstream iss;
    for (auto &item : vs){
        iss.str(item);
        string str2;
        while (iss >> str2)
            cout << str2 << ' ';
        cout << endl;
        iss.clear();
    }
    return EXIT_SUCCESS;
}
