#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
    cout << "因为string和vector<string>均含有默认构造函数，"
        << "或者说都含有值初始化值" << endl;
	return EXIT_SUCCESS;
}
