#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
using std::ifstream;
using std::ofstream;
using std::cout;
using std::endl;
using std::string;
using std::cin;
using std::cerr;
using std::istream;
using std::ostream;
struct Sales_data;
Sales_data &add(const Sales_data &, const Sales_data &);
istream &read(istream &, Sales_data &);
ostream &print(ostream &, const Sales_data &);
class Sales_data{
	friend Sales_data &add(const Sales_data &, const Sales_data &);
	friend istream &read(istream &, Sales_data &);
	friend ostream &print(ostream &, const Sales_data &);
public:
	Sales_data(): Sales_data(""){
        //cout << "Sales_data()" << endl;
    };
    Sales_data(const string &s): Sales_data(s, 0){
        //cout << "Sales_data(const string &)" << endl;
    }
    Sales_data(const string &s, const unsigned &u): Sales_data(s, u, 0.0){
        //cout << "Sales_data(const string &, const unsigned &)" << endl;
    }
	Sales_data(const string &s, const unsigned &u, const double &d):
        bookNo(s), units_sold(u), revenue(d){
            cout << "Sales_data(const string &, consn unsigned &,"
                << " const double &)" << endl;
        }
	Sales_data(istream &is){read(is, *this);}
private:
	string bookNo;
	unsigned units_sold = 0;
	double revenue = 0.0;
public:
	Sales_data &combine(const Sales_data&);
	string isbn() const {return bookNo;};
};
int main(int argc, char **argv){
    if (argc < 3){
        cerr << "Please point input file." << endl;
        return EXIT_FAILURE;
    }
    ifstream iof(argv[1]);
    if (iof.fail()){
        cerr << "Input file is inviold." << endl;
        return EXIT_FAILURE;
    }
    ofstream oof(argv[2], ofstream::app);
    if (oof.fail()){
        cerr << "Output file is inviold." << endl;
        return EXIT_FAILURE;
    }
	Sales_data total(iof);
	if (iof){
		Sales_data trans(iof);
		while (iof){
			if (total.isbn() == trans.isbn()){
				total.combine(trans);
			}
			else{
				print(oof, total);
				total = trans;
				//total.bookNo = trans.bookNo;
				//total.units_sold = trans.units_sold;
				//total.revenue = trans.revenue;
			}
			read(iof, trans);
		} 
		print(oof, total);
	}else{
		cerr << "No Data?" << endl;
		return EXIT_FAILURE;
	}
    iof.close();
    oof.close();
	return EXIT_SUCCESS;
}
Sales_data &Sales_data::combine(const Sales_data &rhs){
	units_sold += rhs.units_sold;
	revenue += rhs.revenue;
	return *this;
}
Sales_data &add(const Sales_data &lhs, const Sales_data &rhs){
	Sales_data sum = lhs;
	return sum.combine(rhs);
}
istream &read(istream &is, Sales_data &item){
	is >> item.bookNo >> item.units_sold >> item.revenue;
	return is;
}
inline ostream &print(ostream &os, const Sales_data &item){
	os << item.isbn() << '\t' << item.units_sold << '\t' 
		<< item.revenue << '\t' << item.revenue / item.units_sold 
		<< endl;
	return os;
}
