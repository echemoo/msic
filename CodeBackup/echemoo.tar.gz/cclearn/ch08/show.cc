#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "" << endl;
	return EXIT_SUCCESS;
}
