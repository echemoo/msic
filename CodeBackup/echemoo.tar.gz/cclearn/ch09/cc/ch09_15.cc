#include <cstdlib>
#include <iostream>
#include <vector>
#include <list>
#include <string>
using std::string;
using std::list;
using std::vector;
using std::cout;
using std::endl;
int compare(const vector<int> &vec1, const vector<int> &vec2){
    if (vec1.size() < vec2.size()){
        for (vector<int>::size_type i = 0; i < vec1.size(); ++i)
            if (vec1[i] == vec2[i])
                ;
            else if (vec1[i] < vec2[i])
                return -1;
            else
                return 1;
        return -1;
    }
    else if (vec1.size() > vec2.size()){
        for (vector<int>::size_type i = 0; i < vec1.size(); ++i)
            if (vec1[i] == vec2[i])
                ;
            else if (vec1[i] < vec2[i])
                return -1;
            else
                return 1;
        return 1;

    }
    else{
        for (vector<int>::size_type i = 0; i < vec1.size(); ++i)
            if (vec1[i] == vec2[i])
                ;
            else if (vec1[i] < vec2[i])
                return -1;
            else
                return 1;
        return 0;
    }
}
int main(int argc, char **argv){
    vector<int> vec1{1, 2, 3, 4, 5, 6, 7};
    vector<int> vec2{1, 2, 3, 4, 5, 6, 8};
    vector<int> vec3{1, 2, 3, 4, 5, 6, 7};
    cout << (vec1 < vec2 ? "vec1 < vec2" : (vec1 > vec2 ? "vec1 > vec2" :
            "vec1 = vec2")) << endl;
    cout << (vec1 < vec3 ? "vec1 < vec3" : (vec1 > vec3 ? "vec1 > vec3" :
            "vec1 = vec3")) << endl;
    cout << "=======================================================" << endl;
    int i1 = compare(vec1, vec2), i2 = compare(vec1, vec3);
    cout << (i1 == 0 ? "vec1 = vec2" : i1 > 0 ? 
            "vec1 > vec2" : "vec1 < vec2") << endl;
    cout << (i2 == 0 ? "vec1 = vec2" : i2 > 0 ? 
            "vec1 > vec2" : "vec1 < vec2") << endl;
	return EXIT_SUCCESS;
}
