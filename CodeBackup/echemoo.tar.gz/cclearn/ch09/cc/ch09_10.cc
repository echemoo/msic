#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "it1:vector<int>::iterator" << endl;
	cout << "it2:vector<int>::const_iterator" << endl;
	cout << "it3:vector<int>::const_iterator" << endl;
	cout << "it4:vector<int>::const_iterator" << endl;
	return EXIT_SUCCESS;
}
