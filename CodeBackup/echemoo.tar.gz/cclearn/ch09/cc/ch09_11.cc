#include <cstdlib>
#include <iostream>
#include <vector>
using std::vector;
using std::cout;
using std::endl;
int main(int argc, char **argv){
    vector<int> vec1;
    vector<int> vec2(vec1);
    vector<int> vec3 = vec2;
    vector<int> vec4{10, 10};
    vector<int> vec5 = {10, 20};
    vector<int> vec6(10);
    vector<int> vec7(10, 20);
	return EXIT_SUCCESS;
}
