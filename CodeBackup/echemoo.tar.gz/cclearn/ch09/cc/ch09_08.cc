#include <cstdlib>
#include <iostream>
#include <list>
using std::cout;
using std::endl;
using std::list;
int main(int argc, char **argv){
    list<int> vec{10, 20, 30, 40};
    for (int i; i != 10; ++i){
        vec.push_front((i+1) * 10);
    }
    for (const list<int>::value_type &it : vec)
      cout << it << '\t';
    cout << endl; 
	return EXIT_SUCCESS;
}
