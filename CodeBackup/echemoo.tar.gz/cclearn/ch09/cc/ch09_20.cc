#include <cstdlib>
#include <iostream>
#include <string>
#include <list>
#include <ctime>
#include <deque>

using std::list;
using std::deque;
using std::endl;
using std::cout;

int main(int argc, char **argv){
    srand(int(time(NULL)));
    list<int> lst;
    deque<int> deq1, deq2;
    for (int i = 0; i < 100; ++i)
        lst.push_front(rand() %  100);
    list<int>::const_iterator cit = lst.cbegin();
    while(cit != lst.cend())
        cout << *cit++ << '\t';
    cout << endl;
    cout << "=====================================================" << endl;
    for (auto it = lst.cbegin(); it != lst.cend(); it++)
       if (*it % 2 == 0)
          deq1.push_back(*it);
        else
           deq2.push_back(*it); 
    for (auto item : deq1)
        cout << item << '\t';
    cout << endl;
    cout << "=====================================================" << endl;
    for (auto item :deq2)
        cout << item << '\t';
    cout << endl;
    cout << "=====================================================" << endl;
    return EXIT_SUCCESS;
}
