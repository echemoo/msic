#include <cstdlib>
#include <iostream>
#include <string>
#include <list>

using std::list;
using std::string;
using std::endl;
using std::cout;
using std::cerr;
using std::cin;

int main(int argc, char **argv){
    list<string> deq;
    string str;
    while (cin >> str)
        deq.push_front(str);
    for (auto item : deq)
        cout << item << '\t';
    cout << endl;
    return EXIT_SUCCESS;
}
