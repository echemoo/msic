#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "两个迭代器必须是相同类型，且指向同一个容器；"
       << "或者指向该容器首前或尾末位置。同时可以通过第一个"
       << "第一个容器反复递增，达到第二个容器的位置。" << endl;
	return EXIT_SUCCESS;
}
