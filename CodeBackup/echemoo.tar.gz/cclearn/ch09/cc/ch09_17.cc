#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "1.c1跟c2必须是相同容器类型且元素类型相同。" << endl;
	cout << "2.c1跟c2元素类型必须定义了关系运算符操作才行。" << endl;
	return EXIT_SUCCESS;
}
