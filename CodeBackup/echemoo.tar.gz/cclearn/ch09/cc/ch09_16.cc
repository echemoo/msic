#include <cstdlib>
#include <iostream>
#include <vector>
#include <list>
#include <string>
using std::string;
using std::list;
using std::vector;
using std::cout;
using std::endl;
int compare(const list<int> &lst1, const vector<int> &vec2){
    if (lst1.size() < vec2.size()){
        auto it = lst1.cbegin();
        for (vector<int>::size_type i = 0;
                i < lst1.size(); ++i, ++it)
            if (*it == vec2[i])
                ;
            else if (*it < vec2[i])
                return -1;
            else
                return 1;
        return -1;
    }
    else if (lst1.size() > vec2.size()){
        auto it = lst1.cbegin();
        for (vector<int>::size_type i = 0;
                i < lst1.size(); ++i, ++it)
            if (*it == vec2[i])
                ;
            else if (*it < vec2[i])
                return -1;
            else
                return 1;
        return 1;
    }
    else{
        auto it = lst1.cbegin();
        for (vector<int>::size_type i = 0;
                i < lst1.size(); ++i, ++it)
            if (*it == vec2[i])
                ;
            else if (*it < vec2[i])
                return -1;
            else
                return 1;
        return 0;
    }
}
int main(int argc, char **argv){
    list<int> lst1{1, 2, 3, 4, 5, 6, 7};
    vector<int> vec2{1, 2, 3, 4, 5, 6, 8};
    vector<int> vec3{1, 2, 3, 4, 5, 6, 7};
    int i1 = compare(lst1, vec2), i2 = compare(lst1, vec3);
    cout << (i1 == 0 ? "lst1 = vec2" : i1 > 0 ? 
            "lst1 > vec2" : "lst1 < vec2") << endl;
    cout << (i2 == 0 ? "lst1 = vec2" : i2 > 0 ? 
            "lst1 > vec2" : "lst1 < vec2") << endl;
	return EXIT_SUCCESS;
}
