#include <cstdlib>
#include <iostream>
#include <vector>
using std::cout;
using std::endl;
using std::vector;
bool find(vector<int>::iterator b, vector<int>::iterator e, int n){
    for (; b != e; ++b){
        if (*b == n)
            return true;
    }
    return false;
}
int main(int argc, char **argv){
    vector<int> vec{10, 20, 30, 40};
	cout << find(vec.begin(), vec.end(), 20) << endl;
	return EXIT_SUCCESS;
}
