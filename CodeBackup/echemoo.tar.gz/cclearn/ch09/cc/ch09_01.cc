#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "(a)适合使用vector，需要快速从尾部插入数据，"
       << "且连续存储节约空间和便于随机方森。" << endl;
	cout << "(b)适合使用deque，需要在两端进行操作。随机访问效率较高。"
       << "且随机访问效率较高。" << endl;
	cout << "(c)没有特别优越的容器，需求无随机访问需求，也无随机插入需求。"
       << "可使用vector，在无特别理由情况下选择vector。" << endl;
	return EXIT_SUCCESS;
}
