#include <cstdlib>
#include <iostream>
#include <list>
#include <deque>
using std::list;
using std::deque;
using std::cout;
using std::endl;
int main(int argc, char **argv){
    list<deque<int>> ldi;
	cout << "list<deque<int>> ldi;" << endl;
	return EXIT_SUCCESS;
}
