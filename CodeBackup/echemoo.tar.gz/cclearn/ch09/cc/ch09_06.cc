#include <cstdlib>
#include <iostream>
#include <list>
using std::list;
using std::cout;
using std::endl;
int main(int argc, char **argv){
    list<int> lst1;
    list<int>::iterator iter1 = lst1.begin(), 
                        iter2 = lst1.end();
    while (iter1 != iter2);
	cout << "迭代器无法进行大小比较操作。" << endl;
	return EXIT_SUCCESS;
}
