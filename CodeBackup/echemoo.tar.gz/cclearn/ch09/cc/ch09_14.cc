#include <cstdlib>
#include <iostream>
#include <vector>
#include <list>
#include <string>
using std::string;
using std::list;
using std::vector;
using std::cout;
using std::endl;
int main(int argc, char **argv){
    list<const char*> lst{"AAA", "BBB", "CCC", "DDD"};
    vector<string> vec(lst.begin(), lst.end());
    for (auto item : vec)
        cout << item << endl;
	return EXIT_SUCCESS;
}
