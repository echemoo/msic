#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "begin返回iterator或者const_iterator.根据容器类型。"
       << "cbegin返回const_iterator." << endl;
	return EXIT_SUCCESS;
}
