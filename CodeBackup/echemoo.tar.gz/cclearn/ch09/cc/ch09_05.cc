#include <cstdlib>
#include <iostream>
#include <vector>
using std::cout;
using std::endl;
using std::vector;
vector<int>::iterator find(vector<int>::iterator b, vector<int>::iterator e, int n){
    for (; b != e; ++b){
        if (*b == n)
            return b;
    }
    return e;
}
int main(int argc, char **argv){
    vector<int> vec{10, 20, 30, 40};
    auto it = find(vec.begin(), vec.end(), 20);
    if (it != vec.end())
        cout << *it << endl;
    else
        cout << "Not find!" << endl;
	return EXIT_SUCCESS;
}
