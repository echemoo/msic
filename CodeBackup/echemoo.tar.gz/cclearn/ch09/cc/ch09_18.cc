#include <cstdlib>
#include <iostream>
#include <string>
#include <deque>

using std::deque;
using std::string;
using std::endl;
using std::cout;
using std::cerr;
using std::cin;

int main(int argc, char **argv){
    deque<string> deq;
    string str;
    while (cin >> str)
        deq.push_back(str);
    for (auto item : deq)
        cout << item << '\t';
    cout << endl;
    return EXIT_SUCCESS;
}
