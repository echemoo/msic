#include <cstdlib>
#include <iostream>
#include <vector>
#include <list>
using std::list;
using std::vector;
using std::cout;
using std::endl;
int main(int argc, char **argv){
    list<int> lst{10, 20, 30, 40};
    vector<int> vec9(lst.begin(), lst.end());
    vector<double> vec10(vec9.begin(), vec9.end());
	return EXIT_SUCCESS;
}
