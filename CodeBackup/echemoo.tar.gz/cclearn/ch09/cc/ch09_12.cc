#include <cstdlib>
#include <iostream>
#include <vector>
using std::vector;
using std::cout;
using std::endl;
int main(int argc, char **argv){
    vector<int> vec7(10, 20);
    vector<int> vec8(vec7);
    vector<int> vec9(vec7.begin(), vec7.end());
	return EXIT_SUCCESS;
}
