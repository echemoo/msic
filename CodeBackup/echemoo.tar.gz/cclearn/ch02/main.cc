#include <iostream>
#include <string>
class Sales_data{
	public:
		std::string bookNo;
		unsigned units_sold{0};
		double revenue = 0.0;
};
int main()
{
	Sales_data currVal;
	double price = 0;
	if (std::cin >> currVal.bookNo >> currVal.units_sold >> price){
		currVal.revenue = currVal.units_sold * price;
		int count = 1;
		Sales_data val;
		while(std::cin >> val.bookNo >> val.units_sold >> price){
			val.revenue = val.units_sold * price;
			if ( val.bookNo == currVal.bookNo ){
				currVal.units_sold += val.units_sold;
				currVal.revenue += val.revenue;
				++count;
			}
			else {
				std::cout << currVal.bookNo << "\t" << currVal.units_sold << "\t" << currVal.revenue << "\t" 
					<< count << "\t" << currVal.revenue / currVal.units_sold << std::endl;
				currVal = val;
				count = 1;
			}
		}	
		std::cout << currVal.bookNo << "\t" << currVal.units_sold << "\t" << currVal.revenue << "\t" 
			<< count << "\t" << currVal.revenue / currVal.units_sold << std::endl;
	}
	else {
		std::cout << "No data ?" << std::endl;
	}
	return 0;
}
		
