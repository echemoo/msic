//2015-03-01 Mon 14:53 CST
//author:echemoo

#include <stdio.h>
#include <assert.h>
#include <unistd.h>

#define BAKBLK "\e[40m" //Black - Background
#define BAKRED "\e[41m" //Red
#define BAKGRN "\e[42m" //Green
#define BAKYLW "\e[43m" //Yello
#define BAKBLU "\e[44m" //Black
#define BAKPUR "\e[45m" //Purple
#define BAKCYN "\e[46m" //Cyan
#define BAKWHT "\e[47m" //White

#define CLRRST "\e[0m"

#define COLOR_NUM 8
#define DELAY_TIME 500000

static const char *color_blocks[]={
	BAKRED" "CLRRST,
	BAKGRN" "CLRRST,
	BAKYLW" "CLRRST,
	BAKBLK" "CLRRST,
	BAKBLU" "CLRRST,
	BAKPUR" "CLRRST,
	BAKCYN" "CLRRST,
	BAKWHT" "CLRRST,
};

static void reset_line();
static unsigned int circle_print_line(unsigned int);
static unsigned int sque_print_line(unsigned int);

int main(int argc, char *argv[])
{
	unsigned int b =0;
	unsigned int (*print_progress)(unsigned int);
	if(argc !=1)
		print_progress = circle_print_line;
	else
		print_progress = sque_print_line;
	for(;;){
		reset_line();
		b = print_progress(b);
		usleep(DELAY_TIME);
	}
	return 0;
}

static void reset_line()
{
	printf("\r                        \r");
}

static unsigned int circle_print_line(unsigned int b)
{
	assert(b < COLOR_NUM);
	unsigned int i =b;
	do {
		printf(color_blocks[i]);
		fflush(stdout);
		i = (i+1)%COLOR_NUM;
	}while(i!=b);
	return (b-1)%COLOR_NUM;
}

static unsigned int sque_print_line(unsigned int c)
{
	assert(c < COLOR_NUM);

	for(unsigned int i=COLOR_NUM -c -1;i<COLOR_NUM;++i){
		printf(color_blocks[i]);
		fflush(stdout);
	}
	return (c+1)% COLOR_NUM;
}
