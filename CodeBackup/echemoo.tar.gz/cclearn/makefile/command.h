#ifndef COMMAND_H
#define COMMAND_H
int sum(int &, int &);
int &add(int &, int &);
int copy(int &);
int &reset(int &);
#endif
