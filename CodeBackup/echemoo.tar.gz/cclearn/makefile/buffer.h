#ifndef BUFFER_H
#define BUFFER_H
int buffer(const int &);
#endif
