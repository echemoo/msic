#ifndef DEFS_H
#define DEFS_H

#define MAX 100
#define MIN 0
#define MID 50

#endif
