#include <iostream>
using std::cout;
using std::endl;
int main(){
	cout << "Hello World!" << endl;
}
