#include <iostream>
#include <string>
using std::string;
using std::cout;
using std::endl;
int main(int argc, char **arg){
	return 0;
}
string f(){
	string s;
	return s;
}
void f2(int i){}
int calc(int v1, int v2){return 0;}
double square(double x){return x * x;}
