#include <cstdlib>
#include <iostream>
#include <vector>
using std::vector;
using std::endl;
using std::cout;
int ff(int, int);
vector<int(*)(int,int)> vf;
int main(int argc, char **argv){
	return EXIT_SUCCESS;
}
