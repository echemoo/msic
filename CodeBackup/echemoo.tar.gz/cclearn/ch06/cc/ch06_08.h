int call_count();
