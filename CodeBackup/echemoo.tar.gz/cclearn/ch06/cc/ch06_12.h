void change(int &,int &);
