#include <vector>
using std::vector;
class matrix;
bool compare(const matrix &, const matrix &);
vector<int>::iterator &change_val(const int &, vector<int>::iterator &);
int main(int argc, char **argv){
	return 0;
}
