#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "对局部对象进行引用返回时无效，返回右值常量的引用时，返回值无效。例如返回字符串字面值的时候，右值常量仅仅为临时空间。" << endl;
	return EXIT_SUCCESS;// EXIT_FAILURE;
}
