#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int &get(int *(&arry), int index){return arry[index];};
int main(int argc, char ** argv){
	int ia[10];
	int *pia = ia;
	for (int i = 0; i != 10; ++i)
		get(pia, i) = i;
	for (auto i : ia)
		cout << i << '\t';
	cout << endl;
	cout << "在gun编译器下不报错，从C++11标准而言，是不允许的，传入的arry为指针，返回的是基于临时变量的引用，返回的值没有意义。" << endl;
	return 0;
}
