#include "ch06_08.h"
int call_count(){
	static int num{0};
	return num++;
}

