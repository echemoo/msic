#include <cstdlib>
#include <iostream>
#include <iterator>
using std::begin;
using std::end;
using std::cout;
using std::endl;
int odd[] = {1, 3, 5, 7, 9};
int even[] = {0, 2, 4, 6, 8};
decltype(odd) &arrPtr(int i){
	return (i % 2) ? odd : even;
}
int main(int argc, char **argv){
	int *ret = arrPtr(1011);
	size_t num = end(odd) - begin(odd);
	for (size_t i = 0; i != num; ++i){
		cout << *ret++ << '\t';
	}
	cout << endl;
	return EXIT_SUCCESS;
}
