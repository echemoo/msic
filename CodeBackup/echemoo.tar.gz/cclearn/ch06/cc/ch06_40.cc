#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int ff(int a, int b = 0, int c = 0);
char *init(int ht, int wd = 10, char bckgrnd = ' ');
char *init(int ht = 24, int wd, char bckgrnd);
int main (int argc, char **argv){
	cout << "a正确，定义的b，c为默认实参。" << endl;
	cout << "B看情况，若前面出现了wd和bckgrnd的默认实参则正确，否者错误。" << endl;
	return EXIT_SUCCESS;
}
