#include "ch06_11.h"
void reset(int &a){
	a = 0;
	return;
}
