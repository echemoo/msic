#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **arg){
	cout << "形参在函数定义的形参表中定义，是一个变量，其作用域为整个函数。实参出现在函数调用中，是一个表达式，进行函数调用时，用传递给函数的实参对形参进行初始化。" << endl;
	return 0;
}
