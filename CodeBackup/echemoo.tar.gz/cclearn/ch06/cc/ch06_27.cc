#include <iostream>
#include <initializer_list>
using std::initializer_list;
using std::cout;
using std::endl;
int sum(initializer_list<int> li);
int main(int argc, char **argv){
	cout << sum({10, 20, 30, 40}) << endl;
	return 0;
}
int sum(initializer_list<int> li){
	int sum{0};
	for (initializer_list<int>::iterator it = li.begin(); 
			it != li.end(); ++it )
		sum += *it;
	return sum;
}
