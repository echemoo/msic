#include <iostream>
using std::cout;
using std::endl;
void print(const int (&)[10]);
int main(int argc, char **argv){
	int test[10] = {};
	print(test);
	return 0;
}
void print(const int (&ia)[10]){
	for (size_t i = 0; i != 10; ++i)
		cout << ia[i] << endl;
	return ;
}


