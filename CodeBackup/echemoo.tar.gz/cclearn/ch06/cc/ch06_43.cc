#include <cstdlib>
#include <iostream>
using std::endl;
using std::cout;
using BigInt = unsigned int;
inline bool eq(const BigInt &, const BigInt &){return true;}
void putValues(int *arr, int size);
int main(int argc, char **argv){
	cout << "eq函数放到头文件中，因为以防不需要的多次定义。" << endl;
	cout << "putValues也放到头文件中，函数声明可重复声明，但定义不同。" << endl;
	return EXIT_SUCCESS;
}
