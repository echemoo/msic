#include <cstdlib>
#include <iostream>
#include <string>
using std::cout;
using std::endl;
using std::string;
typedef string str_10[10];
using str_20 = string[20];
string (&fun_array(string (&)[10]))[10];
str_10 &fun_array2(str_10 &);
auto fun_arry3(str_20 &) -> string (&)[20];
string test[10] = {};
decltype(test) &fun_arry4(decltype(test) &);
int main(int argc, char **argv){
	string str_arr[10];
	for (auto &item : str_arr)
		item = "AAA";
	for (auto &item : str_arr)
		cout << item << '\t';
	cout << endl;
	string str_brr[10] = fun_array(str_arr);
	for (auto &item : str_brr)
		cout << item << '\t';
	cout << endl;
	cout << "个人觉得使用尾置返回类型更好，返回类型更加直观。" << endl;
	return EXIT_SUCCESS;
}
string (&fun_array(string (&arr)[10]))[10]{
	for (auto &item : arr)
		item = "BBB";
	return arr;
}
