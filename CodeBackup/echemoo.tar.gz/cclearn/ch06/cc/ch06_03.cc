#include <iostream>
using std::cout;
using std::endl;
int fact(int );
int main(int argc, char **argv){
	cout << 5 << endl;
	cout << fact(5) << endl;
	return 0;
}
int fact(int num){
	int result{1};
	for(; num > 0; --num)
		result *= num;
	return result;
}
