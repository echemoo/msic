#include <iostream>
#include <initializer_list>
#include <string>
#include <sstream>
using std::stringstream;
using std::cout;
using std::endl;
using std::initializer_list;
using std::string;
class ErrCode{
	public:
		string msg();
		ErrCode() = default;
		ErrCode(int code): codeNum(code){}
	private:
		int codeNum = 0;
};
void error_msg(ErrCode, initializer_list<string>);
int main(int argc, char **argv){
	error_msg(ErrCode(42), {"AAA", "BBB", "CCC"});
	error_msg(ErrCode(0), {"DDDAAA", "EEEBBB", "FFFCCC"});
	return 0;
}
string ErrCode::msg(){
	string str_msg;
	string str_codeNum;
	stringstream ss;
	ss << codeNum;
	ss >> str_codeNum;
	switch(codeNum){
		case 0:
			str_msg =  "ErrCode is null";
			break;
		default:
			str_msg += "ErrCode is ";
			str_msg += str_codeNum;
			//str_msg = "ErrCode is " + codeNum;
			break;
	}
	return str_msg;
}
void error_msg(ErrCode e, initializer_list<string> li){
	cout << e.msg() << ':';
	for (const auto &elem : li)
		cout << elem << ' ';
	cout << endl;
	return;
}
