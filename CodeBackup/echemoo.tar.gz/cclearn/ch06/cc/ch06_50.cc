#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
void f(){cout << "f()" << endl; return;}
void f(int a){cout << "f(int)" << endl; return;}
void f(int a, int b){cout << "f(int,int)" << endl; return;}
void f(double a, double b = 3.14){cout << "f(double,double)" << endl; return;}
int main(int argc, char **argv){
	f(2.56, 42);  //二意性
	f(42);        //f(int)
	f(42,0);	//f(int,int)
	f(2.56, 3.14); //f(double,double)
	return EXIT_SUCCESS;
}
