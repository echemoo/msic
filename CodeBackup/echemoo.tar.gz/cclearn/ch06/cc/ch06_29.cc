#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "应当声明为常量引用类型，避免类型拷贝所消耗的空间。" << endl;
	return 0;
}
