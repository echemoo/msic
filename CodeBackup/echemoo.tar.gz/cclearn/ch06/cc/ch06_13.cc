#include <iostream>
using std::cout;
using std::endl;
int main(){
	cout << "void f(T)定义形参为T的拷贝，void f(&T)定义形参为T的引用传值。" << endl;
	return 0;
}
