#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
inline int factorial(int val){
	if (val != 0)
		return factorial(val - 1) * val;
	return 1;
}
int main(){
	cout << factorial(5) << endl;
	cout << factorial(-5) << endl;
	cout << "正数时，没有影响，负数时则发生错误！" << endl;
	return EXIT_SUCCESS;
}
