#include "ch06_12.h"
void change(int &a, int &b){
	a = a ^ b;
	b = a ^ b;
	a = a ^ b;
	return;
}
