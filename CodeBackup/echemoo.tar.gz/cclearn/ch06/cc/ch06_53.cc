#include <cstdlib>
#include <iostream>
int calc0(int&, int&){return 0;}
int calc0(const int&, const int&){return 0;}
int calc1(char*, char*){return 0;}
int calc1(const char*, const char*){return 0;}
int calc2(char*, char*){return 0;}
int calc2(char * const, char * const){return 0;}
int main(){}
