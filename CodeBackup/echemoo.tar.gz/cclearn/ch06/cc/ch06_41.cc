#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int *init(int ht, int wd = 80, char bckgrnd = ' '){
	return nullptr;
}
int main(int argc, char **argv){
	//init();  //传参错误！
	init(24, 10); //OK
	init(14, '*'); //看似正确，实则意义不对。
	return EXIT_SUCCESS;
}
