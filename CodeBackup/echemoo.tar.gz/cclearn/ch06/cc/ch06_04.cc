#include <iostream>
using std::cout;
using std::endl;
using std::cin;
long fact(int);
int main(int argc, char **argv){
	int val{0};
	cin >> val;
	cout << fact(val) << endl;
	return 0;
}
long fact(int num){
	long result{1};
	for(; num > 0; --num)
		result *= num;
	return result;
}
