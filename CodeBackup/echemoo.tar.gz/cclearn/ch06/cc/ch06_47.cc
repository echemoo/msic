#include <cstdlib>
#include <cassert>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
using std::stringstream;
using std::vector;
using std::string;
using std::endl;
using std::cout;
using std::cerr;
inline string num2str(const int &num){
	stringstream ss;
	string str;
	ss << num;
	ss >> str;
	return str;
}
void print_vi(vector<string>::const_iterator &,
		vector<string>::const_iterator &);
int main(int argc, char **argv){
	vector<string> vi;
	for (int i = 0; i != 100; ++i)
		vi.push_back(string("Hello World! NUM:") + num2str(i));
	for (auto item : vi)
		cout << item << endl;
	auto pbeg = vi.cbegin();
	auto pend = vi.cend();
	print_vi(pbeg, pend);
	return EXIT_SUCCESS;
}
void print_vi(vector<string>::const_iterator &pbeg,
		vector<string>::const_iterator &pend){
	assert(pbeg + 1 != pend);
	if (pbeg != pend){
#ifndef NDEBUG
		cerr << "Error: " << __FILE__ << ": in function "
			<< __func__ << "at line " << __LINE__ << endl
			<< "\t\tComplied on " << __DATE__ << " at "
			<< __TIME__ << endl << "\t\tWord read was \""
			<< *pbeg << "\": Length too short" << endl;
#endif
		cout << *pbeg << endl;
		print_vi(++pbeg, pend);
	}
	return;
}

