#include <iostream>
using std::cout;
using std::endl;
void change(int &, int&);
int abs(int);
int main(){
	int a{10}, b{20};
	cout << a << '\t' << endl;
	change(a, b);
	cout << a << '\t' << endl;
	int c{-10}, d = abs(c);
	cout << c << '\t' << d << endl;
	return 0;
}
void change(int &a, int &b){
	a = a ^ b;
	b = a ^ b;
	a = a ^ b;
	return;
}
int abs(int a){
	return a > 0 ? a : -a;
}
