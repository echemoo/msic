#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
inline int factorial(int val){
	if (val > 0)
		return factorial(val - 1) * val;
	return 1;
}
int main(){
	cout << factorial(5) << endl;
	cout << factorial(-5) << endl;
	cout << "val--返回的是val的值，没有递减，而且无法确定乘号两边的计算顺序。" << endl;
	return EXIT_SUCCESS;
}
