void reset(int &);
