#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
void manip(int, int){}
double dobj;
int main(int argc, char **argv){
	manip('a', 'z'); //3 类型提升
	manip(55.4, dobj); //4 算术类型转换
	return EXIT_SUCCESS;
}
