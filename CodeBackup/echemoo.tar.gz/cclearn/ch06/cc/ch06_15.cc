#include <iostream>
#include <string>
using std::cout;
using std::endl;
using std::string;
void findchar(const string &,const char &, int &);
int main(int argc, char **argv){
	string s1 = "Hello World!";
	int s1_cnt = 0;
	const string s2 = "Hello World! Hi echemoo!";
	int s2_cnt = 0;
	int c_char_cnt = 0;
	findchar(s1, 'o', s1_cnt);
	findchar(s2, 'o', s2_cnt);
	findchar("Hello World! Echemoo!echemoo", 'o', c_char_cnt);
	cout << s1_cnt << '\t' << s2_cnt << '\t' << c_char_cnt << endl;
	return 0;
}
void findchar(const string &str,const char &ch, int &cnt){
	for (const char item : str)
		if (item == ch)
			++cnt;
	return;
}
