#include <iostream>
using std::cout;
using std::endl;
int max(int, int *);
int main(int argc, char **argv){
	int a{20}, c{10}, *b{&c};
	cout << "max:\t" << max(a, b) << endl;
	return 0;
}
int max(int x, int *y){
	return x > *y ? x : *y;
}
