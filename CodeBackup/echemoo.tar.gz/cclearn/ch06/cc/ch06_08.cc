#include <iostream>
#include "ch06_08.h"
using std::cout;
using std::endl;
int main(){
	cout << call_count() << endl;
	cout << call_count() << endl;
	cout << call_count() << endl;
	cout << call_count() << endl;
	cout << call_count() << endl;
	cout << call_count() << endl;
	return 0;
}
int call_count(){
	static int num{0};
	return num++;
}

