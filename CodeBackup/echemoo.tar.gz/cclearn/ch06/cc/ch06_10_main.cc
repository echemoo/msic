#include <iostream>
#include "ch06_10.h"
using std::cout;
using std::endl;
int main(){
	int a = 10, b = 20;
	cout << a << '\t' << b << endl;
	change(&a, &b);
	cout << a << '\t' << b << endl;
	return 0;
}
