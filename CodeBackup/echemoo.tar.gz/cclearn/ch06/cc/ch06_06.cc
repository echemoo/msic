#include <iostream>
using std::cout;
using std::endl;
int test(int);
int main(int argc, char **arg){
	cout << "形参为函数定义时，参数列表中的变量。属于函数局部变量，局部变量为在形参列表和函数内部定义的变量，生命周期仅仅存在于函数内部。局部静态变量从第一次调用函数开始初始化，生命周期到程序执行完成结束。" << endl;
	cout << test(10) << endl;
	cout << test(12) << endl;
	return 0;
}
int test(int a){
	int b{0};
	static int c{0};
	++c;
	return c;
}
