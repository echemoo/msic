#include <iostream>
#include <cstdlib>
#include <cassert>
#include <string>
using std::string;
using std::cout;
using std::endl;
using std::cin;
int main(int argc, char **argv){
	string s;
	string sought = "hello";
	while (cin >> s && s != sought){}
	assert(cin);
	cout << "循环判断标准流出错，或者等于sought的值时，退出循环。assert合理，通过cin状态判断方式，确定s是否等于sought的值，与判断期望 s == sought一致。" << endl;
	return EXIT_SUCCESS;
}
