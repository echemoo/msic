void change(int*,int*);
