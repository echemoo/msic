#include <cstdlib>
#include <iostream>
#include <string>
#include <iterator>
using std::end;
using std::cout;
using std::endl;
using std::string;
string make_plural(const string &word, char ending = 's'){
	auto it = end(word);
	return *(++it) == 's' ? word : word + ending;
}
int main(int argc, char **argv){
	cout << make_plural("success") << endl;
	cout << make_plural("failure") << endl;
	return EXIT_SUCCESS;
}
