#include <iostream>
using std::cin;
using std::cout;
using std::endl;
int abs(int);
int main(int argc, char **argv){
	int val;
	cin >> val;
	cout << abs(val) << endl;
	return 0;
}
int abs(int num){
	return num > 0 ? num : -num;
}
