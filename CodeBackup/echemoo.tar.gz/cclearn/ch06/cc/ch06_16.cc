#include <iostream>
#include <string>
using std::string;
using std::cout;
using std::endl;
bool is_empty(const string &);
int main(int argc, char **argv){
	cout << is_empty("") << endl;
	return 0;
}
bool is_empty(const string &s){
	return s.empty();
}
