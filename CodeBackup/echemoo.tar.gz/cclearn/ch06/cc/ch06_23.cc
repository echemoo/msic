#include <iostream>
#include <iterator>
using std::begin;
using std::end;
using std::cout;
using std::endl;
void print(const int *beg, const int *end);
void print(const int*, size_t size);
int main(int argc, char **argv){
	int i = 0, j[2] = {0, 1};
	print(&i, 1);
	print(j, 2);
	print(&i, nullptr);
	print(begin(j), end(j));
	return 0;
}
void print(const int *beg, const int *end){
	if(end != nullptr){
		for (auto it = beg; it != end; ++it)
			cout << *it << '\t';
		cout << endl;
	}
	else {
		cout << *beg << endl;
	}
	return ;
}
void print(const int *array, size_t size){
	const int *arr = array;
	for (size_t i = 0; i < size; ++i, ++arr)
		cout << *arr << '\t';
	cout << endl;
	return ;
}
