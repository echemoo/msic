#include <iostream>
#include <string>
using std::cout;
using std::endl;
using std::string;
bool is_contain_upper(const string &);
void to_lower(string &);
int main(){
	cout << "不需要修改时，使用const，需要修改时，使用非const" << endl;
	return 0;
}
