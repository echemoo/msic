#include <cstdlib>
#include <iostream>
#include <vector>
#include <string>
#include <sstream>
using std::stringstream;
using std::vector;
using std::string;
using std::cout;
using std::endl;
void ShowVectorItem(vector<string>::const_iterator &,
	       vector<string>::const_iterator &);
string int_to_str(int &);
int main (int argc, char **argv){
	vector<string> vs(100,"Hello!");
	int i = 0;
	for (auto &item : vs){
		item += "Hello!";
		item += int_to_str(++i);
		cout << item << endl;
	}
	auto beg = vs.cbegin();
	auto last = vs.cend();
	ShowVectorItem(beg, last);
	return EXIT_SUCCESS;
}
string int_to_str(int &num){
	stringstream ss;
	string str;
	ss << num;
	ss >> str;
	return str;
}
void ShowVectorItem(vector<string>::const_iterator &beg,
	       vector<string>::const_iterator &last){
	if (beg != last){
		cout << *beg << endl;
		ShowVectorItem(++beg, last);
	}
	return;
}
