#include <cstdlib>
#include <iostream>
#include <vector>
using std::vector;
using std::endl;
using std::cout;
int f1(int&, int&);
int f2(int&, int&);
int f3(int&, int&);
int f4(int&, int&);
vector<int (*)(int &,int &)> vf;
int main(int argc, char **argv){
	vf.push_back(f1);
	vf.push_back(f2);
	vf.push_back(f3);
	vf.push_back(f4);
	int a = 1000, b = 250;
	for (auto item : vf)
		cout << (*item)(a, b) << endl;
	return EXIT_SUCCESS;
}
int f1(int &a, int &b){
	return a + b;
}
int f2(int &a, int &b){
	return a - b;
}
int f3(int &a, int &b){
	return a * b;
}
int f4(int &a, int &b){
	return a / b;
}
