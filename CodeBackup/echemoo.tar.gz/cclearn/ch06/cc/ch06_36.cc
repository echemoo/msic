#include <cstdlib>
#include <iostream>
#include <string>
using std::cout;
using std::endl;
using std::string;
using str_20 = string[20];
string (&fun_array(string (&)[10]))[10];
int main(int argc, char **argv){
	string str_arr[10];
	for (auto &item : str_arr)
		item = "AAA";
	for (auto &item : str_arr)
		cout << item << '\t';
	cout << endl;
	string str_brr[10] = fun_array(str_arr);
	for (auto &item : str_brr)
		cout << item << '\t';
	cout << endl;
	return EXIT_SUCCESS;
}
string (&fun_array(string (&arr)[10]))[10]{
	for (auto &item : arr)
		item = "BBB";
	return arr;
}
