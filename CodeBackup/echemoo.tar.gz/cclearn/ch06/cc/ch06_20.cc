#include <iostream>
using std::cout;
using std::endl;
int main(){
	cout << "不需要变更时使用const，需要修改时使用非const。若常量引用设置为非常量引用，会给用户错误的提示，告知用户该值可能会改变。" << endl;
	return 0;
}
