#include <iostream>
#include <cstdlib>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "候选函数：函数匹配时，函数名相同的一组重载函数的集合。" << endl;
	cout << "可行函数：候选函数中能被实参调用的函数集合。" << endl;
	return EXIT_SUCCESS;
}
