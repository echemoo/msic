#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "若规模较小，流程直接，频繁调用，则使用inline函数，否则不使用！" << endl;
	return EXIT_SUCCESS;
}
