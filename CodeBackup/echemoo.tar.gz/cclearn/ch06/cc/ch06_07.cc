int call_count();
int main(int argc, char **argv){
	call_count();
	return 0;
}
int call_count(){
	static int num{0};
	return num++;
}
