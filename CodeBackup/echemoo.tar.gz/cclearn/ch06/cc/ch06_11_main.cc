#include <iostream>
#include "ch06_11.h"
using std::cout;
using std::endl;
int main(int argc, char **argv){
	int a = 100;
	cout << a << endl;
	reset(a);
	cout << a << endl;
	return 0;
}
