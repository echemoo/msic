#include <cstdlib>
#include <iostream>
#include <string>
using std::string;
using std::endl;
using std::cout;
constexpr bool isShorter(const string &str1, const string &str2){
	return str1.size() <= str2.size();
}		
int main(int argc, char **argv){
	cout << "不可以定义为constexpr函数，传入的字符串需要调用size方法，size方法为非constexpr函数。" << endl;
	return EXIT_SUCCESS;
}
