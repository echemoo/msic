#include <iostream>
using std::cout;
using std::endl;
bool change(int *&, int *&);
int main(int argc, char **argv){
	int x{10}, y{20}, *a(&x), *b{&y};
	cout << "x:\t" << x << "\ty:\t" << y<< "\t*a\t" << *a << "\t*b\t" << *b << endl;
	if (change(a, b))
		cout << "True." << endl;
	else
		cout << "False." << endl;
	cout << "x:\t" << x << "\ty:\t" << y<< "\t*a\t" << *a << "\t*b\t" << *b << endl;
	return 0;
}
bool change(int *(&a), int *(&b)){
	int *c = a;
	a = b;
	b = c;
	return true;
}
