#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int calc(int *, int *){cout << "int" << endl;return 0;}
int calc(const int *, const int *){cout << "const int" << endl;return 0;}
//int get();
//double get();
int *reset(int*);
double *reset(double *);
int main(int argc, char **argv){
	int a = 10, b = 10;
	const int c = 10, d = 10;
	calc (&a, &b);
	calc (&c, &d);
	return EXIT_SUCCESS;
}
