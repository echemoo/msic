#include <iostream>
#include <vector>
using std::vector;
using std::cout;
using std::endl;
int get_value();
int main(){
	char ival = 0;
	int acnt{0}, ecnt{0}, ioucnt{0};
	vector<int> ivec(10,10);
	switch(ival){
		case 'a':
			++acnt;
			break;
		case 'e':
			++ecnt;
			break;
		default:
			++ioucnt;
	}
	int ix{0};
	switch(ival){
		case 1:
			ix = get_value();
			ivec[ ix ] = ival;
			break;
		default:
			ix = ivec.size() - 1;
			ivec[ ix ] = ival;
	}
	int oddcnt{0}, evencnt{0};
	switch (ival){
		case 1:
		case 3:
		case 5:
		case 7:
		case 9:
			++oddcnt;
			break;
		case 2:
		case 4:
		case 6:
		case 8:
		case 10:
			++evencnt;
			break;
		default:
			break;
	}
	constexpr int i_val = 512, jval = 1024, kval = 4096;
	int bufsize;
	int swt{0};
	switch (swt)
	{
		case 512:
			bufsize = i_val * sizeof(int);
			break;
		case 1024:
			bufsize = jval * sizeof(int);
			break;
		case 4096:
			bufsize = kval * sizeof(int);
			break;
	}
	return 0;
}
int get_value(){
	return 0;
}
