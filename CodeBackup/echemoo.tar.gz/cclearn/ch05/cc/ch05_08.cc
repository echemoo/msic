#include <iostream>
using std::cout;
using std::endl;
int main(){
	cout << "多个if对应一个else时，存在else匹配哪个if的问题。该问题叫做悬垂else，c++的做法是匹配离else最近的一个if。" << endl ;
	return 0;
}
