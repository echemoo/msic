#include <iostream>
using std::cout;
using std::endl;
int main(){
	cout << "块语句用一堆花括号表示，后面不跟分号，花括号内为一系列语句，也可以为空。用于只需要一条语句，却需要执行多条语句的情况，以及隔离变量的作用。" << endl;
	return 0;
}
