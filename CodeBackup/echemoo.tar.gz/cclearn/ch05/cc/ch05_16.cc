#include <iostream>
using std::cout;
using std::endl;
int main(){
	constexpr size_t size = 100;
	int ia[size]{};
	size_t ix = 0;
	while (ix != size){
		;
		++ix;
	}
	for (size_t iix = 0; iix != size; ++iix)
		;
	ix = 0;
	do {
		;
		++ix;
	} while (ix != size);
	for(auto item : ia)
		cout << item << '\t';
	cout << endl;
	cout << "更愿意选择for语句" << endl;
	return 0;
}
