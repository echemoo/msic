#include <iostream>
#include <string>
using std::string;
using std::cout;
using std::endl;
using std::cin;
int main(){
	do {
		string s1, s2;
		if (cin >> s1 >> s2)
			cout << (s1.size() < s2.size() ? s1 : s2) << endl;
	} while (cin);
	return 0;
}
