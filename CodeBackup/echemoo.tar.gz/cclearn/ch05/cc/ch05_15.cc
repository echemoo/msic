#include <iostream>
using std::cout;
using std::endl;
int main(){
	int ix = 0, sz = 100;
	for (; ix != sz; ++ix)
		;
	if (ix != sz)
		;
	for (; ix != sz; ++ix)
		;
	for (ix = 0; ix != sz ; ++ix, --sz)
		;
	return 0;
}
