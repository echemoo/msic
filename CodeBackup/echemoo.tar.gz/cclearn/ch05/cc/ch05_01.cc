#include <iostream>
using std::cout;
using std::endl;
int main(){
	cout << "只有分号的语句叫空语句。用于需要语句，却不需要做任何处理的地方。例如if语句，循环体语句。" << endl;
	return 0;
}
