#include <iostream>
using std::cout;
using std::endl;
int get_value();
int main(){
	int ival1 = 10;
	int ival2 = 12;
	int minval = 4;
	int occurs = 0;
	if (ival1 != ival2)
		ival1 = ival2;
	else
		ival1 = ival2 = 0;
	if (ival1 < minval){
		minval = ival1;
		occurs = 1;
	}
	int ival;
	//if (ival = get_value())
	if (ival = 10)
		cout << "ival = " << ival << endl;
	if(!ival)
		cout << "ival = 0\n";
	if (ival == 0)
		ival = get_value();
	return 0;
}
int get_value(){
	return 0;
}
