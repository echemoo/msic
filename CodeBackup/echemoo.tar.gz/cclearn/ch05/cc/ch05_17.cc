#include <iostream>
#include <vector>
using std::vector;
using std::cout;
using std::endl;
using std::cin;
int main(){
	vector<int> ivec1;
	vector<int> ivec2;
	int ival{0};
	while (cin >> ival && ival != -1)
		ivec1.push_back(ival);
	while (cin >> ival && ival != -1)
		ivec2.push_back(ival);
	vector<int>::size_type size1{0}, size2{0};
	size1 = ivec1.size();
	size2 = ivec2.size();
	bool result = true;
	for (vector<int>::size_type ix = 0; 
			ix != (size1 > size2 ? size2 : size1);
			++ix)
		if (ivec1[ix] != ivec2[ix]){
			result = false;
			break;
		}
	if(result)
		if (size1 < size2)
			cout << "The first vector is prefix of the second one."
				<< endl;
		else if (size1 == size2)
			cout << "Two vectors are equal." << endl;
		else
			cout << "The second vector is prefix of the first one"
				<< endl;
	else
		cout << "No vector is prefix of the other one." << endl;
	return 0;
}
