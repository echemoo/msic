#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
using std::string;
using std::cout;
using std::endl;
int main(){
	string s[] = {"F", "D", "C", "B", "A", "A++"};
	srand(unsigned(time(NULL)));
	for (int i = 0; i< 10; ++i){
		unsigned num = rand() % 100;
		cout << num << '\t' << (num < 60 ? s[0] : s[(num - 50) / 10])
			<< endl;
	}
	return 0;
}

