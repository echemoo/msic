#include <iostream>
#include <string>
using std::string;
using std::cout;
using std::endl;
using std::cin;
bool find(string word);
int main(){
//	while (string::iterator item != s.end())
//		;
	string s = "Hello World!";
	string::iterator iter = s.begin();
	while (iter != s.end())
		++iter;
	string word;
	bool status = find(word);
	while (status = find(word))
		cin >> word;
//	while (bool status = find(word))
//		;
	if (!status)
		cout << "OK" << endl;
	return 0;
}
bool find(string word)
{
	return true;
}
