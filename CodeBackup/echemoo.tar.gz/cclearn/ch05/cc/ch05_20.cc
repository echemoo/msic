#include <iostream>
#include <string>
using std::cout;
using std::endl;
using std::cin;
using std::string;
int main(){
	string currWord, preWord;
	cout << "Enter some words:(Ctrl + Z to end)" << endl;
	while (cin >> currWord)
		if (currWord == preWord)
			break;
		else
			preWord = currWord;
	if (currWord == preWord && !currWord.empty())
		cout << "The repeated is : " << currWord << endl;
	else
		cout << "There is no repeated word." << endl;
	return 0;
}
