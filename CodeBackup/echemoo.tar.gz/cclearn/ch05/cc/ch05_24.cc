#include <iostream>
#include <stdexcept>
using std::cout;
using std::endl;
using std::cin;
using std::exception;
int main(){
	int i{0}, j{0};
	if (cin >> i >> j){
		if (j ==0)
			throw exception();
		cout << i / j << endl;
	}
	return 0;
}
