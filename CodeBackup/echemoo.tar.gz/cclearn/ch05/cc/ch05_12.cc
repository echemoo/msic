#include <iostream>
using std::cout;
using std::endl;
using std::cin;
int main(){
	char ch{0}, val{0};
	int ff_cnt{0}, fl_cnt{0}, fi_cnt{0};
	while (cin.get(ch)){
		switch(ch){
			case 'f':
				if (val == 'f'){
					++ff_cnt;
					val = 0;
				}
				else 
					val = 'f';
				break;
			case 'l':
				if (val == 'f'){
					++fl_cnt;
					val = 0;
				}
				break;
			case 'i':
				if (val == 'f'){
					++fi_cnt;
					val = 0;
				}
				break;
			default:
				break;
		}
	}
	cout << "ff:\t" << ff_cnt << endl;
	cout << "fl:\t" << fl_cnt << endl;
	cout << "fi:\t" << fi_cnt << endl;
	return 0;
}
