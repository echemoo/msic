#include <iostream>
using std::cout;
using std::endl;
using std::cin;
int main(){
	int aCnt = 0, eCnt = 0, iCnt = 0, oCnt = 0, uCnt = 0;
	char ch;
	while (cin >> ch)
		if (ch == 'a')
			++aCnt;
		else if (ch == 'e')
			++eCnt;
		else if (ch == 'i')
			++iCnt;
		else if (ch == 'o')
			++oCnt;
		else if (ch == 'u')
			++uCnt;
	cout << "a:\t" << aCnt << endl;
	cout << "e:\t" << eCnt << endl;
	cout << "i:\t" << iCnt << endl;
	cout << "o:\t" << oCnt << endl;
	cout << "u:\t" << uCnt << endl;
	return 0;
}
