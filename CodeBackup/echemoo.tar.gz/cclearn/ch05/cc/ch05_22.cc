int get_size();
int main(){
	int sz = 0;
	do {
		sz = get_size();
	} while (sz <= 0);
}
int get_size(){
	return 1;
}
