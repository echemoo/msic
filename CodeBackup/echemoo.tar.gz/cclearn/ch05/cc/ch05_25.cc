#include <iostream>
#include <stdexcept>
using std::cout;
using std::endl;
using std::cin;
using std::runtime_error;
int main(){
	int i{0}, j{0};
	while (cin >> i >> j){
		try {
			if (j == 0 )
				throw runtime_error("j不能为0.");
			cout << i / j << endl;
			break;
		} catch (runtime_error err){
			cout << err.what() << endl;
			cout << "是否重新输入？输入y继续，其他退出。" << endl;
			char ch = 0;
			cin >> ch;
			if (cin && (ch == 'y' || ch == 'Y'))
				continue;
			else
				break;
		}
	}
	return 0;
}
