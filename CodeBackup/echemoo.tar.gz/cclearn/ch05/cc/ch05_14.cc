#include <iostream>
#include <string>
using std::cout;
using std::endl;
using std::cin;
using std::string;
int main(){
	string m_s;
	string m_max;
	string m_val;
	int max_cnt{1}, val_cnt{1};
	while (cin >> m_s)
		if (m_s == m_val){
			++val_cnt;
			if (val_cnt > max_cnt){
				m_max = m_val;
				max_cnt = val_cnt;
			}
		}
		else{
			m_val = m_s;
			val_cnt = 1;
		}
	cout << m_max << '\t' << max_cnt << endl;
	return 0;
}
