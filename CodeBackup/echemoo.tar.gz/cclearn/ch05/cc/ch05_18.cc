#include <iostream>
using std::cout;
using std::endl;
using std::cin;
int get_response();
int main(){
	do{
		int v1, v2;
		cout << "Please enter two numbers to sum:" << endl;
		if (cin >> v1 >> v2)
			cout << "Sum is " << v1 + v2 << endl;
	} while(cin);
	int ival{0};
	do{
		;
	} while (ival = get_response());
	ival = 0;
	do {
		 ival = get_response();
	} while(ival);
	return 0;
}
int get_response(){
	return 0;
}
