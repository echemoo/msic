#include <iostream>
using std::cout;
using std::endl;
using std::cin;
int main(){
	int aCnt = 0, eCnt = 0, iCnt = 0, oCnt = 0, uCnt = 0;
	char ch;
	while (cin >> ch)
		switch (ch){
			case 'a':
			case 'A':
				++aCnt;
				break;
			case 'e':
			case 'E':
				++eCnt;
				break;
			case 'i':
			case 'I':
				++iCnt;
				break;
			case 'o':
			case 'O':
				++oCnt;
				break;
			case 'u':
			case 'U':
				++uCnt;
				break;
			default:
				break;
		}
	cout << "a:\t" << aCnt << endl;
	cout << "e:\t" << eCnt << endl;
	cout << "i:\t" << iCnt << endl;
	cout << "o:\t" << oCnt << endl;
	cout << "u:\t" << uCnt << endl;
	return 0;
}
