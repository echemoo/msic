#include <iostream>
using std::cout;
using std::endl;
using std::cin;
int main(){
	int i{0}, j{0};
	if (cin >> i >> j)
		cout << i / j << endl;
	return 0;
}
