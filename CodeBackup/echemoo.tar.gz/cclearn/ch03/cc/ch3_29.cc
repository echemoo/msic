#include <iostream>
using std::endl;
using std::cout;
int main(){
	cout << "长度不可变，不允许拷贝和复制，函数内不能默认初始化。" << endl;
	return 0;
}
