#include <iostream>
using std::cout;
using std::endl;
int main(){
	const char ca[] = {'h', 'e', 'l', 'l', 'o'};
	const char *cp = ca;
	while(*cp){
		cout << *cp << endl;
		++cp;
	}
	cout << "没有以\\0空字符结束，可能会连续输出，依赖编译器。" << endl;
	return 0;
}
