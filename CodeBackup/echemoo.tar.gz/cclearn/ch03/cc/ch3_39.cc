#include <iostream> 
#include <iterator>
#include <cstring>
#include <string>
using std::cout;
using std::endl;
using std::string;
using std::begin;
using std::end;
int main(){
	string s1 = "A string example";
	string s2 = "A different string";
	cout << "s1:\t" << s1 << endl;
	cout << "s2:\t" << s2 << endl;
	if (s1 < s2)
		cout << "s1 < s2" << endl;
	else if(s1 > s2)
		cout << "s1 > s2" << endl;
	else
		cout << "s1 = s2" <<endl;
	const char ca1[] = "A string example";
	const char ca2[] = "A different string";
	const char *cp = ca1;
	cout << "ca1:\t";
	while (*cp){
		cout << *cp;
		++cp;
	}
	cout << endl;
	cp = ca2;
	cout << "ca2:\t";
	while (*cp){
		cout << *cp;
		++cp;
	}
	cout << endl;
	size_t ca1_size = end(ca1) - begin(ca1);
	size_t ca2_size = end(ca2) - begin(ca2);
	if (ca1_size > ca2_size)
		cout << "ca1 > ca2" << endl;
	else if (ca1_size < ca2_size)
		cout << "ca1 < ca2" << endl;
	else{
		bool iseq = true;
		for (size_t i = 0; i < ca1_size; ++i)
			if (ca1[i] < ca2[i]){
				cout << "ca1 < ca2" << endl;
				iseq = false;
				break;
			}
			else if (ca1 > ca2){
				cout << "ca1 > ca2" << endl;
				iseq = false;
				break;
			}
		if(iseq)
			cout << "ca1 eq ca2" << endl;
	}
	if (strcmp(ca1, ca2) > 0)
		cout << "ca1 > ca2" << endl;
	else if (strcmp(ca1, ca2) < 0)
		cout << "cat1 < cat2" << endl;
	else
		cout << "cat1 eq cat2" <<endl;
	return 0;
}
