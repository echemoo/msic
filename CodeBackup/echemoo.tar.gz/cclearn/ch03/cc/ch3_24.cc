#include <iostream>
#include <vector>
using std::cout;
using std::endl;
using std::cin;
using std::vector;
int main(){
	vector<int> m_Vi;
	int input;
	while (cin >> input)
		m_Vi.push_back(input);
	for (auto it = m_Vi.cbegin(); (it + 1) != m_Vi.cend(); ++it)
		cout << *it + *(it + 1) << '\t';
	cout << endl;
	for (auto it = m_Vi.cbegin(); (it + 1) != m_Vi.cend(); ++it)
		cout << *it + *(it + (m_Vi.cend() - it) - 1) << '\t';
	cout << endl;
	return 0;
}
