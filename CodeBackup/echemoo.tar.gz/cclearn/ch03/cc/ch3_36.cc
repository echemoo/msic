#include <iostream>
#include <vector>
#include <iterator>
#include <cstddef>
using std::endl;
using std::cout;
using std::vector;
using std::begin;
using std::end;
int main(){
	int ia[100]{};
	int ib[100]{};
	bool iseq{true};
	ptrdiff_t length{end(ia) - begin(ia)};
	if (length  == (end(ib) - begin (ib)))
		for (int i = 0; i < length; ++i)
			if (ia[i] != ib[i]){
				iseq = false;
				cout << i << endl;
				break;
			}
			else{}
	else{
		cout << "Length not eq." << endl;	
		iseq = false;
			}
	vector<int> vi(100,0);
	vector<int> vb(100,1);
	bool iseq1 {(vi == vb)};
	cout << iseq << '\t' << iseq1 << endl;
	return 0;
}
