#include <iostream>
#include <vector>
using std::cin;
using std::cout;
using std::endl;
using std::vector;
int main()
{
	vector<int> m_vec_i;
	int val;
	cout << "Input a list of numbers.:i" << endl;
	while (cin >> val){
		m_vec_i.push_back(val);
	}
	for (auto i : m_vec_i)
		cout << i << "\t" ;
	cout << endl;
	return 0;
}

