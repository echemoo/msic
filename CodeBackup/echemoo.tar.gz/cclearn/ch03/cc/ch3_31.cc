#include <iostream>
using std::cout;
using std::endl;
int main(){
	int ia[10]{};
	for (int i = 0; i < 10; ++i)
		ia[i] = i;
	for (int item : ia)
		cout << item << '\t';
	cout << endl;
	return 0;
}
