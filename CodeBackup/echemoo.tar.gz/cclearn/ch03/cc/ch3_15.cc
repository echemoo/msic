#include <iostream>
#include <string>
#include <vector>
using std::string;
using std::vector;
using std::cout;
using std::cin;
using std::endl;
int main(){
	vector<string> m_vec_s;
	string val;
	while (cin >> val)
		m_vec_s.push_back(val);
	for (auto i : m_vec_s)
		cout << i << '\t';
	cout << endl;
	return 0;
}
