#include <iostream>
#include <vector>
using std::endl;
using std::cout;
using std::cin;
using std::vector;
int main(){
	vector<int> m_Vi;
	int val;
	while (cin >> val)
		m_Vi.push_back(val);
	for (vector<int>::iterator it = m_Vi.begin(); it != m_Vi.end(); ++ it)
		*it = *it * 2;
	for (auto item : m_Vi)
		cout << item << '\t';
	cout << endl;
	return 0;
}
