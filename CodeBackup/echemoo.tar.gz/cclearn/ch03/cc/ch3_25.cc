#include <iostream>
#include <vector>
using std::cout;
using std::cin;
using std::endl;
using std::vector;
int main(){
	vector<int> m_Vi(11,0);
	int input;
	vector<int>::iterator it = m_Vi.begin();
	while (cin >> input)
		++*(it + input / 10);
	for (auto item : m_Vi)
		cout << item << '\t';
	cout << endl;
	return 0;
}
