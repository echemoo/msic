#include <iostream>
#include <vector>
using std::endl;
using std::cout;
using std::vector;
int main(){
	vector<int> vi;
	for (int i = 0; i <= 100; ++i)
		vi.push_back(i);
	const int *p1 = &vi[0];
	const int *p2 = &vi[vi.size()-1];
	cout << "p1\t" << p1 << *p1 << endl;
	cout << "p2\t" << p2 << *p2 << endl;
	p1 += p2 - p1;
	cout << "p1\t" << p1 << *p1 << endl;
	cout << "p2\t" << p2 << *p2 << endl;
	cout << "p2赋值给p1，p1和p2必须指向同一个数组或者对象列表。" << endl;
	return 0;

}
