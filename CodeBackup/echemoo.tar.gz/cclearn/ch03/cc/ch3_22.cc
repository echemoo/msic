#include <iostream>
#include <string>
#include <vector>
#include <cctype>
using std::endl;
using std::cout;
using std::cin;
using std::vector;
using std::string;
int main(){
	vector<string> m_VS;
	string val;
	while (getline(cin,val))
		m_VS.push_back(val);
	for (auto it = m_VS.begin(); it != m_VS.end() && !it->empty(); ++it)
		for (auto its = it->begin(); its != it->end(); ++its)
			*its = toupper(*its);
	for (auto it = m_VS.cbegin(); it != m_VS.cend(); ++it)
		cout << *it << endl;
	return 0;
}
