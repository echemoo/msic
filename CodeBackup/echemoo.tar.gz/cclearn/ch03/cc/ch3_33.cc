#include <iostream>
#include <vector>
using std::cout;
using std::cin;
using std::endl;
using std::vector;
int main(){
	unsigned scores[11];
	unsigned grade;
	while (cin >> grade){
		if(grade <= 100)
			++scores[grade/10];
	}
	for (auto i : scores)
		cout << i << '\t';
	cout << endl;
	cout << "值未初始化，每次访问时，值是不确定的" << endl;
	return 0;
}
