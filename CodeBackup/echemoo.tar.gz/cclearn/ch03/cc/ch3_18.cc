/*
 * Error occored.
 */
#include <vector>
using std::vector;
int main(){
	vector<int> ivec;
	//ivec[0] = 42; //Error.
	ivec.push_back(42);
	vector<int> ivec2(1);
	ivec2[0] =42;
	return 0;
}
