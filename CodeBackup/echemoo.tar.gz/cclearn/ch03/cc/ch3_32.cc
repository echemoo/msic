#include <iostream>
#include <vector>
using std::cout;
using std::endl;
using std::vector;
int main(){
	int ia[10]{};
	int ib[10]{};
	vector<int> vi, vi2;
	for (int i = 0; i < 10; ++i)
		ia[i] = i;
	for (int item : ia)
		cout << item << '\t';
	cout << endl;
	for (int i = 0; i < 10; ++i)
		ib[i] = ia[i];
	for (int item : ib)
		cout << item << '\t';
	cout << endl;
	for (int i = 0; i < 10; ++i)
		vi.push_back(i);
	vi2 = vi;
	for (int item : vi)
		cout << item << '\t';
	cout << endl;
	for (int item : vi2)
		cout << item << '\t';
	cout << endl;
	return 0;
}
