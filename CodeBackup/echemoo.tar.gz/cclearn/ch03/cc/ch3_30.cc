#include <iostream>
using std::cout;
using std::endl;
int main(){
	constexpr size_t array_size = 10;
	int ia[array_size] = {};
	for (size_t ix = 1; ix <= array_size; ++ix)
		//ia[ix] = ix;//Error.
		ia[ix - 1] = ix;
	for (int item : ia)
		cout << item << '\t';
	cout << endl;
	return 0;
}
