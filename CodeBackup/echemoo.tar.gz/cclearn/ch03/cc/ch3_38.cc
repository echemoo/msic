#include <iostream>
using std::cout;
using std::endl;
int main(){
	cout << "指针的运算操作是为了操作数组或这vector等适配操作，指针直接相加无法获取定位到操作序列的任意元素。" << endl;
	return 0;
}
