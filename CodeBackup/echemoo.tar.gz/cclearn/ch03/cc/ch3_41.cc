#include <iostream>
#include <vector>
using std::vector;
using std::cout;
using std::endl;
int main(){
	int ia[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
	vector<int> vi(ia,ia + sizeof(ia)/sizeof(int));
	int ib[100]{};
	cout << "ia:\t" << endl;
	for (int item : ia)
		cout << item << '\t';
	cout << endl << "vi:\t" << endl;
	for (auto item : vi)
		cout << item << '\t';
	cout << endl << "ib:\t" << endl;
	for (int item : ib)
		cout << item << '\t';
	cout << endl;
	for (size_t  i = 0; i < vi.size(); ++i)
		ib[i] = vi[i];
	cout << "ia:\t" << endl;
	for (int item : ia)
		cout << item << '\t';
	cout << endl << "vi:\t" << endl;
	for (auto item : vi)
		cout << item << '\t';
	cout << endl << "ib:\t" << endl;
	for (int item : ib)
		cout << item << '\t';
	cout << endl;
	return 0;
}
