#include <iostream>
#include <string>
#include <vector>
#include <cctype>
using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::vector;
int main(){
	vector<string> m_vec_s;
	string input;
	while (cin >> input)
		m_vec_s.push_back(input);
	for (auto &i : m_vec_s)
		cout << i << endl;
	cout << "=========================" << endl;
	for (auto &i : m_vec_s){
		for (auto &j : i)
			j = toupper(j);
		cout << i << endl;
	}
	return 0;
}
