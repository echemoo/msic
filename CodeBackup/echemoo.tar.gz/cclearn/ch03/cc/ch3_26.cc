//使用mid = (begin + end) / 2;
//指针+指针是没有意义的
#include <iostream>
#include <vector>
using std::cout;
using std::cin;
using std::endl;
using std::vector;
int main(){
	vector<unsigned char> m_Vuc;
	for(int i = 0; i < 128; ++i )
		m_Vuc.push_back(i);
	unsigned char target{0};
	cin >> target;
	auto it_begin = m_Vuc.begin();
	auto it_end = m_Vuc.end();
	auto it_mid = it_begin + (it_end - it_begin) / 2;
	while (it_mid != it_end && *it_mid != target){
		if (target < *it_mid)
			it_end = it_mid;
		else 
			it_begin = it_mid + 1;
		it_mid = it_begin + (it_end - it_begin) / 2;
	}
	cout << it_mid - m_Vuc.cbegin() << endl;
	return 0;

}
