#include <iostream>
#include <string>
#include <vector>
using std::string;
using std::vector;
using std::cout;
using std::endl;
int main(){
	vector<int> v1;
	vector<int> v2(10);
	vector<int> v3(10,42);
	vector<int> v4{10};
	vector<int> v5{10,42};
	vector<string> v6{10};
	vector<string> v7{10,"hi"};
	cout << "v1:\t" << v1.size() << endl;
	for (auto i : v1)
		cout << i << '\t';
	cout << endl;
	cout << "v2:\t" << v2.size() << endl;
	for (auto i : v2)
		cout << i << '\t';
	cout << endl;
	cout << "v3:\t" << v3.size() << endl;
	for (auto i : v3)
		cout << i << '\t';
	cout << endl;
	cout << "v4:\t" << v4.size() << endl;
	for (auto i : v4)
		cout << i << '\t';
	cout << endl;
	cout << "v5:\t" << v5.size() << endl;
	for (auto i : v5)
		cout << i << '\t';
	cout << endl;
	cout << "v6:\t" << v6.size() << endl;
	for (auto i : v6)
		cout << i << '\t';
	cout << endl;
	cout << "v7:\t" << v7.size() << endl;
	for (auto i : v7)
		cout << i << '\t';
	cout << endl;
	return 0;
}
