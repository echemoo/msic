#include <iostream>
#include <iterator>
using std::begin;
using std::cout;
using std::endl;
using std::end;
int main(){
	int ia[10]{};
	for (int &i : ia)
		i = 0;
	for (int i = 0; i < 10; ++i)
		ia[i] = 0;
	for (int *pi = begin(ia); pi != end(ia); ++pi )
		*pi = 0;
	for (int i : ia)
		cout << i << '\t';
	cout << endl;
	return 0;
}
