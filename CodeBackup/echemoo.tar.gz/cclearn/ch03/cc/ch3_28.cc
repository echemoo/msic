#include <iostream>
using std::endl;
using std::cout;
int main(){
	cout << "sa\n" << "10个空字符" << endl;
	cout << "ia\n" << "10个0" << endl;
	cout << "sa2\n" << "10个未确定值" << endl;
	cout << "ia2\n" << "10个未确定值" << endl;
	return 0;
}
