#include <iostream>
#include <vector>
using std::vector;
using std::cout;
using std::cin;
using std::endl;
int main(){
	vector<int> m_Vi;
	int input{0};
	while (cin >> input)
		m_Vi.push_back(input);
	for (auto i : m_Vi)
		cout << i << '\t';
	cout << endl;
	for (int i = 0; i < m_Vi.size() - 1; ++i)
		cout << m_Vi[i] + m_Vi[i+1] << '\t';
	cout << endl;
	for (int i = 0; i < m_Vi.size() - 1; ++i)
		cout << m_Vi[i] + m_Vi[m_Vi.size() - 1 - i] << '\t';
	cout << endl;
}
