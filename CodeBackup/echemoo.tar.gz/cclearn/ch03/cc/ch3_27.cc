#include <iostream>
using std::cout;
using std::endl;
int txt_size(){
	return 0;
}
int main(){
	unsigned buf_size = 1024;
	int ia[buf_size];//OK
	int ib[4 * 7 -14];//OK
	int ic[txt_size()];//ERROR
	char st[11] = "fundamental";//ERROR
	return 0;

}
