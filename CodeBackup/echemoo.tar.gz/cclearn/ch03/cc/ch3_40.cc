#include <iostream>
#include <cstring>
#include <iterator>
using std::cout;
using std::endl;
using std::begin;
using std::end;
int main (){
	constexpr char ca[] = "Hello World!";
	constexpr char cb[] = "Hello echemoo!"; 
	char cc[(sizeof(ca) + sizeof(cb)) / sizeof(char) - 1]{};
	cout << "ca:\t";
	for(auto item : ca)
		cout << item;
	cout << endl << "cb:\t";
	for (auto item : cb)
		cout << item;
	cout << endl << "cc:\t";
	for (auto item : cc)
		cout << item;
	cout << endl;
	strcpy(cc, ca);
	strcat(cc, cb);
	cout << "ca:\t";
	for(auto item : ca)
		cout << item;
	cout << endl << "cb:\t";
	for (auto item : cb)
		cout << item;
	cout << endl << "cc:\t";
	for (auto item : cc)
		cout << item;
	cout << endl;
	return 0;
}
