#include <iostream>
#include <cstdlib>
class NoDefault{
public:
    NoDefault(const int &i): item(i){}
private:
    int item;
};
class C{
public:
    C():C(NoDefault(10)){}
    C(const NoDefault &no): item(no){}
private:
    NoDefault item;
};
int main(int argc, char **argv){
    C c;
    return EXIT_SUCCESS;
}
