#include <string>
using std::string;
struct Persion{
	string name;
	string addr;
	string getName() const {return name;}
	string getAddr() const {return addr;}
};
