#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "vector是模版类，存在数量和类型的指定，传单一构造无法确定具体操作"
       << "容易引起语法混乱，比如：vector<int> i(10)." << endl;
	return EXIT_SUCCESS;
}
