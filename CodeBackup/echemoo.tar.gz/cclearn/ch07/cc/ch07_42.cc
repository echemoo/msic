#include <iostream>
#include <cstdlib>
using std::cout;
using std::endl;
class Data{
public:
    Data(): Data(1970, 1, 1){cout << "Data();" << endl;};
    Data(const int &y,const int &m,const int &d): year(y), month(m), day(d){
        cout << "Data(const int &, const int &, const int &)" << endl;
    }
private:
    int year, month, day;
};
int main(){
    Data d1;
    Data d2(2015, 3, 31);
    cout << "Data：需要年：int year，月：int month；日：int day"
        << "构造两个构造函数，一个默认构造函数，用于创建空的date对象，"
        << "一个带有三个形参，用于创建指定日期的对象。" << endl;
    return EXIT_SUCCESS;
}
