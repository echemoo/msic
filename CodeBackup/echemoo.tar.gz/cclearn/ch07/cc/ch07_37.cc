#include <iostream>
#include <string>
using std::cout;
using std::endl;
class Sales_data;
void read(std::istream &, Sales_data);
class Sales_data{
    friend void read(std::istream &, Sales_data);
public:
    Sales_data(std::string s = ""): bookNo(s){}
    Sales_data(std::string s, unsigned cnt, double rev): 
        bookNo(s), units_sold(cnt), revenue(rev * cnt){}
    Sales_data(std::istream &is){read(is,*this);}
private:
    std::string bookNo;
    unsigned units_sold;
    double revenue;
};
void read(std::istream &is, Sales_data sd){
    is >> sd.bookNo >> sd.units_sold >> sd.revenue;
    return;
}
Sales_data first_item(std::cin);
int main(){
    Sales_data next;
    Sales_data last("9-999-99999-9");
    cout << "first_item通过cin初始化，调用第三个构造函数，"
       << "next通过第一个构造函数默认初始化，"
       << "last通过第一个够着函数显式初始化。" << endl;
}
