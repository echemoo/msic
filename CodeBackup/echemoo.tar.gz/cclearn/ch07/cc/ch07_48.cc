#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "1. 调用接收C风格字符串形参的string构造函数，创建一个临时的"
       << "string对象，然后调用string类的复制构造函数，将null_isbn"
       << "初始化为该临时变量的副本。" << endl;
    cout << "2. 使用string的对象null_isbn为实参，调用Sales_item类的构造函"
       << "创建Sales_item对象null1。" << endl;
    cout << "3. 使用接受一个C风格字符串形参的string类的构造函数，生成"
       << "一个string临时对象，然后用这个临时对象作为实参，调用Sales_item"
       << "类的构造函数来创建Sales_item类的对象。" << endl;
	return EXIT_SUCCESS;
}
