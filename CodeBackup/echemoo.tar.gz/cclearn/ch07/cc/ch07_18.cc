#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "封装指类的内部实现和成员对外不可见，可以有效的保护成员不被破坏，同时保证实现和接口的分离。" << endl;
	return EXIT_SUCCESS;
}
