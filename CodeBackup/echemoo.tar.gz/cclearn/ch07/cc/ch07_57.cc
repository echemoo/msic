#include <cstdlib>
#include <iostream>
#include <string>
using std::cout;
using std::endl;
using std::string;
class Account{
public:
    Account() = default;
    Account(string own, double am): owner(own), amount(am){}
    void applyint(){
        amount += amount * interestRate;
    }
    static double rate(){
        return interestRate;
    }
    static void rate(double newRate){
        interestRate = newRate;
    }
private:
    string owner;
    double amount;
    static double interestRate;
};
double Account::interestRate = 0.0016;
int main(int argc, char **argv){
    Account acc;
    return EXIT_SUCCESS;
}
