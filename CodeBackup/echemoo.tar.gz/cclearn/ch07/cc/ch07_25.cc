#include <cstdlib>
#include <iostream>
#include <string>
using std::string;
using std::cout;
using std::endl;
class Screen{
public:
    typedef std::string::size_type pos;
    Screen() = default;
    Screen(pos ht, pos wd): height(ht), width(wd), contents(ht * wd, ' '){};
    Screen(pos ht, pos wd, char c): height(ht), width(wd), 
        contents(ht * wd, c){};
    inline char get() const {return contents[cursor];}
    char get(pos ht, pos wd) const;
    Screen &move(pos r, pos c);
    Screen &print();
private:
    pos cursor = 0;
    pos height = 0, width = 0;
    std::string contents;
};
int main(int argc, char **argv){
    Screen sr;
    Screen sr2(10, 10, '#');
    Screen sr3 = sr2;
    sr.print();
    sr2.print();
    sr3.print();
    cout << "能安全地依赖拷贝和赋值操作的默认版本，所有类成员均含有默认值初始化"
       << "或者类内值初始化。"  << endl;
    return EXIT_SUCCESS;
}
inline Screen &Screen::move(pos r, pos c){
    cursor = r * width + c;
    return *this;
}
char Screen::get(pos ht, pos wd) const{
    return contents[ht * width + wd];
}
inline Screen &Screen::print(){
    for(pos i = 0; i != width; ++i){
        for(pos j = 0; j != height; ++j)
            cout << contents[i * width + j] << ' ';
        cout << endl;
    }
    return *this;
}
