#include <iostream>
#include <cstdlib>
#include <string>
using std::cout;
using std::endl;
using std::string;
using std::cin;
using std::cerr;
using std::istream;
using std::ostream;
struct Sales_data{
	string bookNo;
	unsigned units_sold = 0;
	double revenue = 0.0;
	Sales_data &combine(const Sales_data&);
	string isbn() const {return bookNo;};
};
Sales_data &add(const Sales_data &, const Sales_data &);
istream &read(istream &, Sales_data &);
ostream &print(ostream &, const Sales_data &);
int main(int argc, char **argv){
	cout << "因为read需要修改Sales_data的值，而print不需要。" << endl;
	Sales_data total;
	if (read(cin, total)){
		Sales_data trans;
		while (read(cin, trans)){
			if (total.isbn() == trans.isbn()){
				total.combine(trans);
			}
			else{
				print(cout, total);
				total.bookNo = trans.bookNo;
				total.units_sold = trans.units_sold;
				total.revenue = trans.revenue;
			}
		} 
		print(cout, total);
	}else{
		cerr << "No Data?" << endl;
		return EXIT_FAILURE;
	}
	return EXIT_SUCCESS;
}
Sales_data &Sales_data::combine(const Sales_data &rhs){
	units_sold += rhs.units_sold;
	revenue += rhs.revenue;
	return *this;
}
Sales_data &add(const Sales_data &lhs, const Sales_data &rhs){
	Sales_data sum = lhs;
	return sum.combine(rhs);
}
istream &read(istream &is, Sales_data &item){
	is >> item.bookNo >> item.units_sold >> item.revenue;
	return is;
}
ostream &print(ostream &os, const Sales_data &item){
	os << item.isbn() << '\t' << item.units_sold << '\t' 
		<< item.revenue << '\t' << item.revenue / item.units_sold 
		<< endl;
	return os;
}
