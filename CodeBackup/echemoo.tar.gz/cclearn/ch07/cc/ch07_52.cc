#include <cstdlib>
#include <string>
#include <iostream>
using std::string;
using std::cout;
using std::endl;
struct Sales_data {
    string bookNo;
    //unsigned units_sold = 0;
    unsigned units_sold;
    //double revenue = 0.0;
    double revenue;
};
int main(){
    cout << "不能含有类内初始值。" << endl;
    Sales_data item = {"978-04040400278", 25, 15.99};
    return EXIT_SUCCESS;
}
