#include <iostream>
#include <cstdlib>
#include <vector>
using std::vector;
using std::cout;
using std::endl;
class X;
class Y;
class X{
public:
    int index = 0;
    Y *next = nullptr;
};
class Y{
public:
    Y(X &x): xbody(x){}
    int index = 0;
    X &xbody;
};
int main(int argc, char **argv){
    vector<X> vx;
    vector<Y> vy;
    for (int i = 0; i != 10; ++i){
        X x;
        x.index = 10 + i;
        vx.push_back(x);
    }
    for (int i = 0; i != 10; ++i){
        Y y(vx[i]);
        y.index = 20 + i;
        vy.push_back(y);
    }
    for (int i = 0; i != 10; ++i){
        vx[i].next = &vy[i];
    }
    for (auto item : vx)
        cout << item.index << '\t' << item.next << endl;
    for (auto item : vy){
        cout << item.index << '\t' 
            << item.xbody.index << '\t'
            << item.xbody.next << endl;
    }
    return EXIT_SUCCESS;
}
