#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "if (read(read(cin, data1), data2))" << endl;
	cout << "依次读取data1和data2，然后判断读取状态。" << endl;
	return EXIT_SUCCESS;
}
