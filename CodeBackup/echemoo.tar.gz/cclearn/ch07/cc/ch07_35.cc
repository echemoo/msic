#include <cstdlib>
#include <string>
#include <iostream>
using std::cout;
using std::endl;
using std::string;
typedef int Type;
//typedef string Type;
Type initVal;
class Exercise{
public:
    //typedef double Type;
    Type setVal(Type);
    Type initVal();
private:
    int val;
};
Type Exercise::setVal(Type parm){
    val = parm + initVal();
    return val;
}
int main(){
    cout << "Type被重复定义，修改后即可：。" << endl;
}
