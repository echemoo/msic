#include <string>
using std::string;
struct Persion{
	string name;
	string addr;
};
