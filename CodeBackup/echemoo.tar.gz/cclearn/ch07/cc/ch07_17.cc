#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "class与struct唯一的区别在于默认访问权限，class默认为private，struct默认为public。" << endl;
	return EXIT_SUCCESS;
}
