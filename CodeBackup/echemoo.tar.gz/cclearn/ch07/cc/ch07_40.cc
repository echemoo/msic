#include <iostream>
#include <cstdlib>
using std::cout;
using std::endl;
class Data{
public:
    Data() = default;
    Data(int y, int m, int d): year(y), month(m), day(d){}
private:
    int year, month, day;
};
int main(){
    Data d1;
    Data d2(2015, 3, 31);
    cout << "Data：需要年：int year，月：int month；日：int day"
        << "构造两个构造函数，一个默认构造函数，用于创建空的date对象，"
        << "一个带有三个形参，用于创建指定日期的对象。" << endl;
    return EXIT_SUCCESS;
}
