#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "应该声明为explicit，如果不声明，编译器可以使用此构造函数进行"
       << "隐式转换，即将一个string类型的对象转换为Sales_item对象，这种"
       << "容易发生语义错误。好处是：可以防止函数的隐式类型转换而带来"
       << "的错误，缺点是：用户需要显式的创建临时对象。" << endl;
	return EXIT_SUCCESS;
}
