#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "友元允许其他类或者函数访问其非共有成员。优点是可在类外访问类的非共有成员，缺点是破坏了类的封装型。" << endl;
	return EXIT_SUCCESS;
}
