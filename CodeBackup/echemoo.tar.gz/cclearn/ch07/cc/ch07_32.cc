#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
using std::vector;
using std::string;
using std::cout;
using std::endl;
class Windows_mgr;
class Screen{
public:
    //friend void Windows_mgr::clear(const ScreenIndex &);
    friend class Windows_mgr;
    typedef std::string::size_type pos;
    Screen() = default;
    Screen(pos ht, pos wd): height(ht), width(wd), contents(ht * wd, ' '){};
    Screen(pos ht, pos wd, char c): height(ht), width(wd), 
        contents(ht * wd, c){};
    inline char get() const {return contents[cursor];}
    char get(pos, pos) const;
    Screen &move(pos,pos);
    const Screen &move(pos,pos) const;
    Screen &set(char);
    const Screen &set(char) const;
    Screen &set(pos, pos, char);
    const Screen &set(pos, pos, char) const;
    Screen &display(std::ostream &os){do_display(os);return *this;}
    const Screen &display(std::ostream &os) const{do_display(os);return *this;}
private:
    mutable pos cursor = 0;
    pos height = 0, width = 0;
    mutable std::string contents;
    void do_display(std::ostream &os) const {os << contents; return;}
};
int main(int argc, char **argv){
    Screen sr(10, 10, '#');
    sr.display(cout);
    cout << endl;
    sr.move(4, 5).set('$').display(cout);
    cout << endl;
    for (Screen::pos i = 0; i != 10; ++i){
        for (Screen::pos j = 0; j!= 10; ++j)
            cout << sr.get(i, j) << ' ';
        cout << endl;
    }
    const Screen csr(10, 10, '*');
    csr.display(cout);
    cout << endl;
    csr.move(4, 5).set('#').display(cout);
    cout << endl;
    for (Screen::pos i = 0; i != 10; ++i){
        for (Screen::pos j = 0; j!= 10; ++j)
            cout << csr.get(i, j) << ' ';
        cout << endl;
    }
    return EXIT_SUCCESS;
}
inline Screen &Screen::move(pos r, pos c){
    cursor = r * width + c;
    return *this;
}
inline const Screen &Screen::move(pos r, pos c) const{
    cursor = r * width + c;
    return *this;
}
Screen &Screen::set(char c){
  contents[cursor] = c;
  return *this; 
}
const Screen &Screen::set(char c) const{
  contents[cursor] = c;
  return *this; 
}
Screen &Screen::set(pos ht, pos wd, char c){
    contents[ht * width + wd] = c;
    return *this;
}
const Screen &Screen::set(pos ht, pos wd, char c) const{
    contents[ht * width + wd] = c;
    return *this;
}
char Screen::get(pos ht, pos wd) const{
    return contents[ht * width + wd];
}
class Windows_mgr{
public:
    using ScreenIndex = std::vector<Screen>::size_type;
    void clear(const ScreenIndex &);
private:
    std::vector<Screen> screen{Screen(24, 80, ' ')};
};
void Windows_mgr::clear(const ScreenIndex &i){
    Screen &s = screen[i];
    s.contents = string(s.height * s.width, ' ');
    return;
}
