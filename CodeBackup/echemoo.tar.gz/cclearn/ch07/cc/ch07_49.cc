#include <cstdlib>
#include <iostream>
#include <string>
using std::string;
using std::cout;
using std::endl;
class A{
public:
    A(string s): item(s) {}
    const A &com(const A &a) const {item += a.item; return *this;}
private:
    mutable string item;
};
int main(int argc, char **argv){
    A a("aaa"), b("bbb");
    string s = "sss";
    a.com(s);
	cout << "1. 发生默认类型转换，正常执行。" << endl;
	cout << "2. 类型不匹配，未发生默认转换。" << endl;
	cout << "3. string作为const A类型的默认实参传入。" << endl;
	return EXIT_SUCCESS;
}
