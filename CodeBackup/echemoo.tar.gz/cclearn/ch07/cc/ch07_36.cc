#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
struct X {
    X(int i, int j): base(i), rem(i % j){}
    X() = default;
    //X(int i, int j): base(i), rem(base % j){}
    //int rem, base;
    int base, rem;
};
int main(){
    cout << "rem比base更先初始化，所以无法使用base对rem进行初始化。"
        << "最好的办法为直接用i替换base。" << endl;
    return 0;
}
