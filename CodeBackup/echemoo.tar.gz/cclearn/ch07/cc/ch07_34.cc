#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "编译报错，typedef前面的所有名称均调试类型错误！" << endl;
	return EXIT_SUCCESS;
}
