#include <cstdlib>
#include <iostream>
#include <string>
using std::string;
using std::cout;
using std::endl;
class Screen{
public:
    typedef std::string::size_type pos;
    Screen() = default;
    Screen(pos ht, pos wd): height(ht), width(wd), contents(ht * wd, ' '){};
    Screen(pos ht, pos wd, char c): height(ht), width(wd), 
        contents(ht * wd, c){};
    inline char get() const {return contents[cursor];}
    inline pos getc() const {return cursor;}
    char get(pos, pos) const;
    Screen move(pos,pos);
    Screen set(char);
    Screen set(pos, pos, char);
    Screen display(std::ostream &os){do_display(os);return *this;}
    const Screen &display(std::ostream &os) const{do_display(os);return *this;}
private:
    pos cursor = 0;
    pos height = 0, width = 0;
    std::string contents;
    void do_display(std::ostream &os) const {os << contents; return;}
};
int main(int argc, char **argv){
    Screen sr(10, 10, '#');
    sr.display(cout);
    cout << endl;
    sr.move(4, 5).set('$').display(cout);
    cout << endl;
    cout << sr.getc() << endl;
    for (Screen::pos i = 0; i != 10; ++i){
        for (Screen::pos j = 0; j!= 10; ++j)
            cout << sr.get(i, j) << ' ';
        cout << endl;
    }
    cout << "因为返回的是右值，为临时对象，所以给予移动操作有效，"
        << "给予赋值操作无效。move操作执行了，set操作未执行，"
        << "display操作也是操作的set传递后的临时对象！" << endl;
    return EXIT_SUCCESS;
}
inline Screen Screen::move(pos r, pos c){
    cursor = r * width + c;
    return *this;
}
Screen Screen::set(char c){
  contents[cursor] = c;
  return *this; 
}
Screen Screen::set(pos ht, pos wd, char c){
    contents[ht * width + wd] = c;
    return *this;
}
char Screen::get(pos ht, pos wd) const{
    return contents[ht * width + wd];
}
