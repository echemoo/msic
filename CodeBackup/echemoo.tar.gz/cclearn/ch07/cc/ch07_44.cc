#include <iostream>
#include <cstdlib>
#include <vector>
using std::vector;
using std::cout;
using std::endl;
class NoDefault{
public:
    NoDefault(const int &i): item(i){}
private:
    int item;
};
class C{
public:
    C():C(NoDefault(10)){}
    C(const NoDefault &no): item(no){}
private:
    NoDefault item;
};
int main(int argc, char **argv){
    vector<NoDefault> vec(10, 10);
    C c;
    cout << "不合法，因为NoDefault没有默认构造函数，必须显式指明。" << endl;
    return EXIT_SUCCESS;
}
