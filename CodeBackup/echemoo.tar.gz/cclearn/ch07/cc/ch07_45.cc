#include <iostream>
#include <cstdlib>
#include <vector>
using std::vector;
using std::cout;
using std::endl;
class NoDefault{
public:
    NoDefault(const int &i): item(i){}
private:
    int item;
};
class C{
public:
    C():C(NoDefault(10)){}
    C(const NoDefault &no): item(no){}
private:
    NoDefault item;
};
int main(int argc, char **argv){
    vector<C> vec(10);
    C c;
    cout << "合法，因为C有默认构造函数，无需显式指明。" << endl;
    return EXIT_SUCCESS;
}
