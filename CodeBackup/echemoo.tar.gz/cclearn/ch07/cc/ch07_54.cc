#include <iostream>
#include <cstdlib>
#include <string>
using std::cout;
using std::endl;
using std::string;
using std::cerr;
class Debug{
public:
    constexpr Debug(bool b = true): hw(b), io(b), other(b){}
    constexpr Debug(bool b, bool i, bool o): hw(b), io(i), other(o){}
    constexpr bool any() {return hw || io || other;}
    void set_io(bool b){hw = b;}
    void set_hw(bool b){hw = b;}
    void set_other(bool b){other = b;}
private:
    bool hw;
    bool io;
    bool other;
};
int main(){
    constexpr Debug io_sub(false, true, true);
    if (io_sub.any())
        cerr << "打印所有错误信息！" << endl;
    constexpr Debug prid(false);
    if (prid.any())
        cerr << "打印一个错误信息！" << endl;
    cout << "不应该声明为constexpr函数，因为函数需要修改类的值。" << endl;
    return EXIT_SUCCESS;
}
