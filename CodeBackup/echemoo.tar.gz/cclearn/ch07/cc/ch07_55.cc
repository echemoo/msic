#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "不是，不含有constexpr构造函数。" << endl;
	return EXIT_SUCCESS;
}
