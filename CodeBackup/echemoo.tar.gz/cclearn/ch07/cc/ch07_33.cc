#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "编译出错：pos未指定定义域。修改方法为在pos前添加Screen::" << endl;
	return EXIT_SUCCESS;
}
