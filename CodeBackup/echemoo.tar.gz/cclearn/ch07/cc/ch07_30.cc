#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "优点：明确的指出成员所属对象。" << endl;
	cout << "缺点：代码敲击麻烦得很。" << endl;
	return EXIT_SUCCESS;
}
