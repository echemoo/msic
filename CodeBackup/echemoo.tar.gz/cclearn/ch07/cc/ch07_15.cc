#include <string>
#include <iostream>
using std::istream;
using std::ostream;
using std::string;
using std::endl;
struct Person{
	Person() = default;
	Person(const string &n): name(n){}
	Person(const string &n, const string &a): name(n), addr(a){}
	Person(istream &is){is >> name >> addr;}
	string name = "admin";
	string addr = "China";
	string getName() const {return name;}
	string getAddr() const {return addr;}
};
istream &read(istream &is, Person &per){
	is >> per.name >> per.addr;
	return is;
}
ostream &print(ostream &os, const Person &per){
	os << per.name << '\t' << per.addr << endl;
	return os;
}
