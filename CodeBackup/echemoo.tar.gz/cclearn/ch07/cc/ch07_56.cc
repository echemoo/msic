#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "类成员声明前有关键字static的类成员为static类成员。"
       << "static成员不是任意对象的组成部分，但由全体类共享。" << endl;
	cout << "优点：1. static成员的名字是在类的作用域中， 因此"
       << "可以避免与其他类的成员或全局对象名称冲突。2。"
       << "可以实施封装，static可以为私有成员，全局成员不可以。3."
       << "通过阅读程序看出static成员是与特定类关联的，这种可见性"
       << "清晰地显示程序员的意图。" << endl;
	cout << "不同点：普通成员是与对象关联的，是某个对象的组成部分，"
       << "而static成员与类相关联，由该类的全体成员共享，不是任意"
       << "的组成部分。" << endl;
	return EXIT_SUCCESS;
}
