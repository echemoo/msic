#include <vector>
#include <iostream>
using std::cout;
using std::endl;
using std::vector;
class Example{
public:
    static double rate;
    static const int vecSize = 20;
    static vector<double> vec;
    static const int add (const int x, const int y);
};
double Example::rate = 6.5;
vector<double> Example::vec(vecSize);
const int Example::vecSize;
int main(int argc, char **argv){
    cout << Example::rate << endl;
    cout << Example::vecSize << endl;
    cout << Example::vec[0] << endl;
    cout << Example::add(10, 10) << endl;
    return EXIT_SUCCESS;
}
const int Example::add(const int x, const int y){
    return x + y;
}
