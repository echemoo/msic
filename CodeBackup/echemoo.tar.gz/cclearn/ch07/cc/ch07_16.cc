#include <cstdlib>
#include <iostream>
using std::cout;
using std::endl;
int main(int argc, char **argv){
	cout << "访问说明符出现位置和使用次数没有限制。需要定义类的接口时使用public，需要封装类的实现细节时， 使用private。" << endl;
	return EXIT_SUCCESS;
}
