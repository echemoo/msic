//目的：测试利用C++ 11特性实现计数器的方法
//操作系统：CentOS 7.0
//publish_data:2015-04-12 13:04
//编写人：李小军[echemoo]
//版本：1.0
//文件名：test.cc
//编译：g++ -Wl,--no-as-needed -std=c++11 test.cc -lpthread 
#include <iostream>
#include <atomic>
#include <thread>
#include <vector>

using std::vector;
using std::thread;
using std::cout;
using std::endl;
using std::atomic_int;

atomic_int Counter(0);
int order[400];

void work(int id){
    int no;
    for (int i = 0; i < 100; i++){
        no = Counter++;
        order[no] = id;
    }
}
int main(int argc, char **argv){
    vector<thread> threads;
    //创建多线程访问计数器
    for (int i = 0; i !=4; ++i)
        //线程工作函数与线程编辑参数
        threads.push_back(thread(work, i));
    for (auto &th : threads)
        th.join();
    //最终的计数值
    cout << "final:" << Counter << endl;
    //观察各线程的工作时序
    for (int i = 0; i < 400; i++)
        cout << "[" << i << "]=" << order[i] << ' ';
    cout << endl;
    return 0;
}
